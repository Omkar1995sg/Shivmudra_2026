import Link from "next/link";
import { BrandingHeader } from "@/components/BrandingHeader";
import { GroupPhotoBackground } from "@/components/GroupPhotoBackground";
import { categoryLabel, type MemberCategory } from "@/lib/member-fields";

const categoryStyles: Record<
  MemberCategory,
  { badge: string; border: string; cardHover: string; titleHover: string }
> = {
  senior: {
    badge: "bg-blue-500/20 text-blue-300 border-blue-500/40",
    border: "border-blue-500/30",
    cardHover: "hover:border-blue-500/60 hover:bg-blue-500/5",
    titleHover: "group-hover:text-blue-400",
  },
  junior: {
    badge: "bg-purple-500/20 text-purple-300 border-purple-500/40",
    border: "border-purple-500/30",
    cardHover: "hover:border-purple-500/60 hover:bg-purple-500/5",
    titleHover: "group-hover:text-purple-400",
  },
};

interface AttendanceEntryPageProps {
  category: MemberCategory;
}

export function AttendanceEntryPage({ category }: AttendanceEntryPageProps) {
  const styles = categoryStyles[category];
  const label = categoryLabel(category);

  return (
    <main className="relative mx-auto flex min-h-screen max-w-lg flex-col justify-center p-6">
      <GroupPhotoBackground />
      <div className="relative">
      <BrandingHeader subtitle="सराव उपस्थिती | Practice Attendance" />
      <span
        className={`mx-auto mt-4 flex w-fit rounded-full border px-4 py-1 text-xs font-semibold ${styles.badge}`}
      >
        {label.toUpperCase()} ONLY
      </span>
      <h1 className="mt-4 text-center text-2xl font-bold text-white">{label} Attendance</h1>
      <p className="mt-2 text-center text-sm text-white/60">
        Sign in to mark {label.toLowerCase()} practice attendance
      </p>

      <div className={`card group mt-8 border-2 text-center ${styles.border} ${styles.cardHover}`}>
        <p className="text-3xl">{category === "senior" ? "🥁" : "🪘"}</p>
        <h2 className={`mt-3 text-xl font-bold text-white ${styles.titleHover}`}>
          {label} Attendance Portal
        </h2>
        <p className="mt-2 text-sm text-white/50">/user/{category}</p>
      </div>

      <div className="mt-6 grid gap-3">
        <Link href={`/login/${category}`} className="btn-primary text-center">
          {label} Sign In
        </Link>
        <Link href={`/user/${category}`} className="btn-secondary text-center">
          {label} Mark Attendance
        </Link>
      </div>
      </div>
    </main>
  );
}
