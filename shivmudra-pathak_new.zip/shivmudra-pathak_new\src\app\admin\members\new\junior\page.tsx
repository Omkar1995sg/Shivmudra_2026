import { AdminRegisterMemberForm } from "@/components/AdminRegisterMemberForm";

export default function RegisterJuniorMemberPage() {
  return <AdminRegisterMemberForm category="junior" />;
}
