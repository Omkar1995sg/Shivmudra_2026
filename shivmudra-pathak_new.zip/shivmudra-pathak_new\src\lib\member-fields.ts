export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] as const;
export type BloodGroup = (typeof BLOOD_GROUPS)[number];

export const MEMBER_CATEGORIES = ["senior", "junior"] as const;
export type MemberCategory = (typeof MEMBER_CATEGORIES)[number];

export function isValidBloodGroup(value: string): value is BloodGroup {
  return (BLOOD_GROUPS as readonly string[]).includes(value);
}

export function isValidMemberCategory(value: string): value is MemberCategory {
  return (MEMBER_CATEGORIES as readonly string[]).includes(value);
}

export function categoryLabel(category: MemberCategory | string | null): string {
  if (category === "senior") return "Senior";
  if (category === "junior") return "Junior";
  return "—";
}

export const INSTRUMENTS = ["dhol", "tasha", "dhawaj"] as const;
export type InstrumentOption = (typeof INSTRUMENTS)[number];

export function instrumentLabel(value: string | null | undefined): string {
  if (value === "dhol") return "Dhol-Dhwaj";
  if (value === "tasha") return "Tasha-Dhwaj";
  if (value === "dhawaj") return "Dhwaj";
  return "—";
}

export interface CategoryAttendanceStats {
  seniorTotal: number;
  juniorTotal: number;
  seniorPresent: number;
  juniorPresent: number;
  total: number;
  totalPresent: number;
}

export function countAttendanceByCategory(
  members: { id: string; member_category: string | null }[],
  presentIds: Set<string>
): CategoryAttendanceStats {
  const senior = members.filter((m) => m.member_category === "senior");
  const junior = members.filter((m) => m.member_category === "junior");
  return {
    seniorTotal: senior.length,
    juniorTotal: junior.length,
    seniorPresent: senior.filter((m) => presentIds.has(m.id)).length,
    juniorPresent: junior.filter((m) => presentIds.has(m.id)).length,
    total: members.length,
    totalPresent: members.filter((m) => presentIds.has(m.id)).length,
  };
}
