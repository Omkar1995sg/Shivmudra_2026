import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profile?.role !== "leader" && profile?.role !== "admin") {
    return NextResponse.json({ error: "Leader or admin only" }, { status: 403 });
  }

  const { user_id, reason } = await request.json();

  if (!user_id || !reason) {
    return NextResponse.json({ error: "user_id and reason required" }, { status: 400 });
  }

  const { error } = await supabase.from("removal_requests").insert({
    user_id,
    raised_by: user.id,
    reason,
    status: "pending",
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({ success: true });
}

export async function PATCH(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profile?.role !== "admin") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const { request_id, action } = await request.json();

  if (!request_id || !["approved", "rejected"].includes(action)) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const { data: req } = await supabase
    .from("removal_requests")
    .select("*")
    .eq("id", request_id)
    .single();

  if (!req) return NextResponse.json({ error: "Not found" }, { status: 404 });

  await supabase
    .from("removal_requests")
    .update({
      status: action,
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", request_id);

  if (action === "approved") {
    const adminClient = createAdminClient();
    await adminClient
      .from("profiles")
      .update({ status: "inactive" })
      .eq("id", req.user_id);
  }

  return NextResponse.json({ success: true });
}
