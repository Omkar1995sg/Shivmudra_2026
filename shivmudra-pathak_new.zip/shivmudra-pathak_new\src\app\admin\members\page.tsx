import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { MemberCard } from "@/components/MemberCard";
import type { Profile } from "@/types/database";

export default async function MembersPage() {
  await requireRole(["admin"]);
  const supabase = await createClient();

  const { data: members } = await supabase
    .from("profiles")
    .select("*")
    .eq("role", "user")
    .eq("approval_status", "approved")
    .eq("status", "active")
    .order("name");

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-6xl p-6">
        <h1 className="mb-6 text-2xl font-bold text-white">Members Gallery</h1>
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {(members as Profile[] | null)?.map((m) => (
            <MemberCard key={m.id} member={m} />
          ))}
        </div>
        {(!members || members.length === 0) && (
          <p className="text-white/50">No members registered yet.</p>
        )}
      </main>
    </>
  );
}
