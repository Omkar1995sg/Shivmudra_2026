"use client";

import { AppNav } from "@/components/AppNav";
import { categoryLabel, instrumentLabel } from "@/lib/member-fields";
import { useEffect, useState } from "react";

interface PendingMember {
  id: string;
  email: string;
  name: string;
  phone: string;
  address: string;
  instrument: string;
  reference: string;
  photo_url: string | null;
  blood_group: string | null;
  member_category: string | null;
  created_at: string;
}

export default function AdminRegistrationsPage() {
  const [pending, setPending] = useState<PendingMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewing, setReviewing] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch("/api/registration/list")
      .then((r) => r.json())
      .then((data) => {
        setPending(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  async function review(userId: string, action: "approved" | "rejected") {
    setReviewing(userId);
    const res = await fetch("/api/registration/review", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId, action }),
    });
    const data = await res.json();
    if (res.ok) {
      setPending((list) => list.filter((m) => m.id !== userId));
      if (!data.emailSent && data.emailNote) {
        alert(`Review saved. Email not sent: ${data.emailNote}`);
      }
    } else {
      alert(data.error ?? "Failed to review");
    }
    setReviewing(null);
  }

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-4xl p-6">
        <h1 className="mb-2 text-2xl font-bold text-white">Registration Requests</h1>
        <p className="mb-6 text-sm text-white/60">
          Approve members before they can mark attendance. Approval email is sent automatically.
        </p>

        {loading && <p className="text-white/50">Loading...</p>}

        <div className="space-y-4">
          {pending.map((m) => (
            <div key={m.id} className="card">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
                {m.photo_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={m.photo_url}
                    alt={m.name}
                    className="h-24 w-24 rounded-xl object-cover"
                  />
                ) : (
                  <div className="flex h-24 w-24 items-center justify-center rounded-xl bg-white/10 text-white/40">
                    No photo
                  </div>
                )}
                <div className="flex-1">
                  <p className="text-lg font-semibold text-white">{m.name}</p>
                  <p className="text-sm capitalize text-brand-500">
                    {categoryLabel(m.member_category)} · {instrumentLabel(m.instrument)}
                  </p>
                  <p className="mt-2 text-sm text-white/70">{m.email}</p>
                  <p className="text-sm text-white/70">{m.phone}</p>
                  {m.blood_group && (
                    <p className="text-sm text-white/60">Blood Group: {m.blood_group}</p>
                  )}
                  {m.address && <p className="text-sm text-white/50">{m.address}</p>}
                  {m.reference && (
                    <p className="text-sm text-white/50">Ref: {m.reference}</p>
                  )}
                  <p className="mt-1 text-xs text-white/40">
                    Applied {new Date(m.created_at).toLocaleString("en-IN")}
                  </p>
                </div>
                <span className="h-fit rounded-full bg-yellow-500/20 px-3 py-1 text-xs text-yellow-300">
                  pending
                </span>
              </div>
              <div className="mt-4 flex gap-2">
                <button
                  onClick={() => review(m.id, "approved")}
                  disabled={reviewing === m.id}
                  className="btn-primary text-sm py-2"
                >
                  {reviewing === m.id ? "..." : "Approve"}
                </button>
                <button
                  onClick={() => review(m.id, "rejected")}
                  disabled={reviewing === m.id}
                  className="btn-secondary text-sm py-2"
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
          {!loading && pending.length === 0 && (
            <p className="text-white/50">No pending registration requests.</p>
          )}
        </div>
      </main>
    </>
  );
}
