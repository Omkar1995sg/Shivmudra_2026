export type UserRole = "admin" | "leader" | "user";
export type Instrument = "dhol" | "tasha" | "dhawaj";
export type MemberStatus = "active" | "inactive";
export type RequestStatus = "pending" | "approved" | "rejected";
export type ApprovalStatus = "pending" | "approved" | "rejected";
export type MemberCategory = "senior" | "junior";

export interface Profile {
  id: string;
  email: string;
  role: UserRole;
  status: MemberStatus;
  approval_status: ApprovalStatus;
  name: string;
  address: string;
  phone: string;
  instrument: Instrument | null;
  reference: string;
  previous_pathak: boolean;
  previous_pathak_name: string | null;
  photo_url: string | null;
  blood_group: string | null;
  member_category: MemberCategory | null;
  section: string | null;
  created_at: string;
  updated_at: string;
}

export interface PracticeGround {
  id: string;
  center_lat: number;
  center_lng: number;
  radius_meters: number;
  name: string;
  set_by: string | null;
  updated_at: string;
}

export interface Attendance {
  id: string;
  user_id: string;
  attendance_date: string;
  marked_at: string;
  latitude: number | null;
  longitude: number | null;
  distance_meters: number | null;
  geo_verified: boolean;
}

export interface RemovalRequest {
  id: string;
  user_id: string;
  raised_by: string;
  reason: string;
  status: RequestStatus;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface ProfileWithAttendance extends Profile {
  attendance?: Attendance[];
}
