"""Set a known temporary password for bootstrap admin and verify password login."""
from __future__ import annotations

import json
import secrets
import string
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EMAIL = "omkargavkhadkar@gmail.com"
UID = "e08a8386-1e1c-4f35-a189-a1f732db214e"


def load_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def req(url: str, headers: dict[str, str], method="GET", body=None):
    data = None if body is None else json.dumps(body).encode()
    h = dict(headers)
    if body is not None:
        h["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(request, timeout=30) as resp:
            raw = resp.read().decode()
            return resp.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else None
        except json.JSONDecodeError:
            payload = {"raw": raw[:400]}
        return e.code, payload


def gen_password(n: int = 14) -> str:
    alphabet = string.ascii_letters + string.digits
    # Ensure mix
    pw = [
        secrets.choice(string.ascii_uppercase),
        secrets.choice(string.ascii_lowercase),
        secrets.choice(string.digits),
    ]
    pw += [secrets.choice(alphabet) for _ in range(n - 3)]
    secrets.SystemRandom().shuffle(pw)
    return "".join(pw)


def main():
    env = load_env(ROOT / ".env.local")
    url = env["NEXT_PUBLIC_SUPABASE_URL"].rstrip("/")
    service = env["SUPABASE_SERVICE_ROLE_KEY"]
    anon = env["NEXT_PUBLIC_SUPABASE_ANON_KEY"]
    password = gen_password()

    # Write temp password to a local file (not committed) so chat need not echo forever
    secret_file = ROOT / ".admin-temp-password.txt"
    secret_file.write_text(
        f"email={EMAIL}\npassword={password}\ncreated_for=local_admin_recovery\n",
        encoding="utf-8",
    )

    headers = {"apikey": service, "Authorization": f"Bearer {service}"}
    st, body = req(
        f"{url}/auth/v1/admin/users/{UID}",
        headers,
        method="PUT",
        body={"password": password, "email_confirm": True},
    )
    print(f"password_update_status={st}")
    if st not in (200, 201):
        print("FAIL update:", body)
        return 1

    # Verify password login
    st, token = req(
        f"{url}/auth/v1/token?grant_type=password",
        {"apikey": anon, "Authorization": f"Bearer {anon}"},
        method="POST",
        body={"email": EMAIL, "password": password},
    )
    print(f"password_login_status={st}")
    if st != 200 or not isinstance(token, dict) or not token.get("access_token"):
        print("FAIL login verify:", token)
        return 1

    access = token["access_token"]
    st, profile = req(
        f"{url}/rest/v1/profiles?select=role,approval_status,status,email&email=eq.{EMAIL}",
        {
            "apikey": anon,
            "Authorization": f"Bearer {access}",
        },
    )
    print(f"profile_as_user_status={st}")
    print("profile:", profile)
    print("PASSWORD_FILE:", str(secret_file))
    print("OK admin password reset and verified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
