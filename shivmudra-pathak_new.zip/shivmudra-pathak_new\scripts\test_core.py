"""Core logic tests for Shivmudra Pathak (no Node required)."""
import math
from datetime import datetime, timezone, timedelta

EARTH_RADIUS_M = 6371000
IST = timezone(timedelta(hours=5, minutes=30))

ATTENDANCE_START = 20 * 60 + 30  # 8:30 PM
ATTENDANCE_END = 21 * 60 + 30    # 9:30 PM


def haversine_m(lat1, lng1, lat2, lng2):
    to_rad = math.radians
    d_lat = to_rad(lat2 - lat1)
    d_lng = to_rad(lng2 - lng1)
    a = math.sin(d_lat / 2) ** 2 + math.cos(to_rad(lat1)) * math.cos(to_rad(lat2)) * math.sin(d_lng / 2) ** 2
    return EARTH_RADIUS_M * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def is_within_fence(user_lat, user_lng, center_lat, center_lng, radius_m):
    d = haversine_m(user_lat, user_lng, center_lat, center_lng)
    return d <= radius_m, round(d)


def is_within_window(hour, minute):
    mins = hour * 60 + minute
    return ATTENDANCE_START <= mins < ATTENDANCE_END


def test_geo_inside_150m():
    center_lat, center_lng = 18.5204, 73.8567
    # ~50m north ≈ 0.00045 degrees lat
    user_lat = center_lat + 0.00045
    inside, dist = is_within_fence(user_lat, center_lng, center_lat, center_lng, 150)
    assert inside, f"Expected inside fence, got {dist}m"
    print(f"PASS geo inside: {dist}m")


def test_geo_outside_150m():
    center_lat, center_lng = 18.5204, 73.8567
    user_lat = center_lat + 0.005  # ~550m
    inside, dist = is_within_fence(user_lat, center_lng, center_lat, center_lng, 150)
    assert not inside, f"Expected outside fence"
    print(f"PASS geo outside: {dist}m")


def test_attendance_window():
    assert is_within_window(20, 30), "8:30 PM should open"
    assert is_within_window(21, 0), "9:00 PM should be open"
    assert not is_within_window(21, 30), "9:30 PM should be closed"
    assert not is_within_window(17, 46), "5:46 PM should be closed"
    print("PASS attendance window boundaries")


def test_project_files():
    import os
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    required = [
        "package.json",
        "src/app/login/page.tsx",
        "src/app/user/page.tsx",
        "src/app/admin/page.tsx",
        "src/app/api/attendance/mark/route.ts",
        "supabase/schema.sql",
    ]
    for f in required:
        path = os.path.join(root, f)
        assert os.path.isfile(path), f"Missing: {f}"
    print(f"PASS all {len(required)} required files exist")


if __name__ == "__main__":
    test_project_files()
    test_geo_inside_150m()
    test_geo_outside_150m()
    test_attendance_window()
    print("\nAll core tests passed.")
