import { CategoryLoginForm } from "@/components/CategoryLoginForm";
import { Suspense } from "react";

export default function JuniorLoginPage() {
  return (
    <Suspense fallback={<div className="p-6 text-center text-white/50">Loading...</div>}>
      <CategoryLoginForm category="junior" />
    </Suspense>
  );
}
