import { AttendancePanel } from "@/components/AttendancePanel";

export default function SeniorAttendancePage() {
  return <AttendancePanel portalCategory="senior" />;
}
