import {
  formatDashboardDate,
  type DailyInstrumentAttendance,
  type InstrumentTodayStats,
} from "@/lib/attendance-stats";

interface InstrumentAttendanceDashboardProps {
  today: string;
  todayStats: InstrumentTodayStats[];
  dailyHistory: DailyInstrumentAttendance[];
  showTitle?: boolean;
}

export function InstrumentAttendanceDashboard({
  today,
  todayStats,
  dailyHistory,
  showTitle = true,
}: InstrumentAttendanceDashboardProps) {
  return (
    <div className="space-y-8">
      {showTitle && (
        <div>
          <h2 className="text-sm font-medium uppercase tracking-wide text-white/40">
            Instrument Summary — Today ({formatDashboardDate(today)})
          </h2>
          <p className="mt-1 text-xs text-white/45">
            Registrations = active approved members. Present = marked attendance today.
          </p>
        </div>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead>
            <tr className="border-b border-white/10 text-white/50">
              <th className="pb-3 pr-4">Instrument</th>
              <th className="pb-3 pr-4 text-right">Senior Registrations</th>
              <th className="pb-3 pr-4 text-right">Senior Present Today</th>
              <th className="pb-3 pr-4 text-right">Junior Registrations</th>
              <th className="pb-3 text-right">Junior Present Today</th>
            </tr>
          </thead>
          <tbody>
            {todayStats.map((row) => (
              <tr key={row.instrument} className="border-b border-white/5">
                <td className="py-3 pr-4 font-medium text-white">{row.label}</td>
                <td className="py-3 pr-4 text-right text-blue-300">{row.seniorRegistrations}</td>
                <td className="py-3 pr-4 text-right text-green-400">{row.seniorPresentToday}</td>
                <td className="py-3 pr-4 text-right text-purple-300">{row.juniorRegistrations}</td>
                <td className="py-3 pr-4 text-right text-green-400">{row.juniorPresentToday}</td>
              </tr>
            ))}
            <tr className="bg-white/5 font-semibold">
              <td className="py-3 pr-4 text-white">Total</td>
              <td className="py-3 pr-4 text-right text-blue-300">
                {todayStats.reduce((s, r) => s + r.seniorRegistrations, 0)}
              </td>
              <td className="py-3 pr-4 text-right text-green-400">
                {todayStats.reduce((s, r) => s + r.seniorPresentToday, 0)}
              </td>
              <td className="py-3 pr-4 text-right text-purple-300">
                {todayStats.reduce((s, r) => s + r.juniorRegistrations, 0)}
              </td>
              <td className="py-3 pr-4 text-right text-green-400">
                {todayStats.reduce((s, r) => s + r.juniorPresentToday, 0)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium uppercase tracking-wide text-white/40">
          Daily Attendance History
        </h2>
        <div className="card max-h-[520px] overflow-auto">
          <table className="w-full min-w-[960px] text-left text-sm">
            <thead className="sticky top-0 bg-[#1a1510]">
              <tr className="border-b border-white/10 text-white/50">
                <th className="pb-3 pr-3">Date</th>
                <th className="pb-3 pr-3 text-right">Dhol-Dhwaj Senior Present</th>
                <th className="pb-3 pr-3 text-right">Dhol-Dhwaj Junior Present</th>
                <th className="pb-3 pr-3 text-right">Tasha-Dhwaj Senior Present</th>
                <th className="pb-3 pr-3 text-right">Tasha-Dhwaj Junior Present</th>
                <th className="pb-3 pr-3 text-right">Dhwaj Senior Present</th>
                <th className="pb-3 pr-3 text-right">Dhwaj Junior Present</th>
                <th className="pb-3 pr-3 text-right">Senior Total</th>
                <th className="pb-3 text-right">Junior Total</th>
              </tr>
            </thead>
            <tbody>
              {dailyHistory.map((row) => (
                <tr key={row.date} className="border-b border-white/5">
                  <td className="py-2.5 pr-3 whitespace-nowrap text-white/80">
                    {formatDashboardDate(row.date)}
                  </td>
                  <td className="py-2.5 pr-3 text-right text-white/70">{row.dholSeniorPresent}</td>
                  <td className="py-2.5 pr-3 text-right text-white/70">{row.dholJuniorPresent}</td>
                  <td className="py-2.5 pr-3 text-right text-white/70">{row.tashaSeniorPresent}</td>
                  <td className="py-2.5 pr-3 text-right text-white/70">{row.tashaJuniorPresent}</td>
                  <td className="py-2.5 pr-3 text-right text-white/70">{row.dhawajSeniorPresent}</td>
                  <td className="py-2.5 pr-3 text-right text-white/70">{row.dhawajJuniorPresent}</td>
                  <td className="py-2.5 pr-3 text-right font-medium text-blue-300">{row.seniorPresentTotal}</td>
                  <td className="py-2.5 pr-3 text-right font-medium text-purple-300">{row.juniorPresentTotal}</td>
                </tr>
              ))}
              {dailyHistory.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-6 text-center text-white/40">
                    No attendance recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
