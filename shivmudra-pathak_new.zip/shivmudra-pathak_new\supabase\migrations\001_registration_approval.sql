-- Phase 1: Registration approval workflow (run on existing Shivmudra DB)

DO $$ BEGIN
  CREATE TYPE approval_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS approval_status approval_status NOT NULL DEFAULT 'pending';

-- Existing active members / admins are grandfathered as approved
UPDATE profiles
SET approval_status = 'approved'
WHERE role IN ('admin', 'leader')
   OR (role = 'user' AND status = 'active');

CREATE INDEX IF NOT EXISTS idx_profiles_approval ON profiles(approval_status);

-- Recreate leader read policy with approval gate
DROP POLICY IF EXISTS "Leader read active members" ON profiles;
CREATE POLICY "Leader read active members" ON profiles
  FOR SELECT USING (
    get_my_role() = 'leader'
    AND status = 'active'
    AND approval_status = 'approved'
  );

-- Bootstrap trigger: new users start pending until admin approves
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  bootstrap_email TEXT := 'omkargavkhadkar@gmail.com';
  assigned_role user_role := 'user';
  member_status_val member_status := 'inactive';
  approval_val approval_status := 'pending';
BEGIN
  IF NEW.email = bootstrap_email THEN
    assigned_role := 'admin';
    member_status_val := 'active';
    approval_val := 'approved';
  END IF;

  INSERT INTO profiles (id, email, role, name, status, approval_status)
  VALUES (
    NEW.id,
    NEW.email,
    assigned_role,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    member_status_val,
    approval_val
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
