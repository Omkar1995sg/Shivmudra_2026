"use client";

import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import { useRouter } from "next/navigation";

interface NavProps {
  role: "admin" | "leader" | "user";
}

const adminLinks = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/senior", label: "Senior" },
  { href: "/admin/junior", label: "Junior" },
  { href: "/admin/registrations", label: "Registrations" },
  { href: "/admin/members", label: "Members" },
  { href: "/admin/members/new", label: "Register" },
  { href: "/admin/leaders", label: "Leaders" },
  { href: "/admin/geo-fence", label: "Geo Fence" },
  { href: "/admin/requests", label: "Requests" },
  { href: "/admin/reports", label: "Reports" },
];

const leaderLinks = [
  { href: "/leader", label: "Attendance" },
  { href: "/leader/requests", label: "Removal Requests" },
];

export function AppNav({ role }: NavProps) {
  const router = useRouter();
  const links = role === "admin" ? adminLinks : role === "leader" ? leaderLinks : [];

  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <header className="border-b border-white/10 bg-black/30 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4">
        <div>
          <p className="text-xs text-brand-500">शिवमुद्रा पथक</p>
          <p className="text-sm font-semibold capitalize text-white">{role} Portal</p>
        </div>
        <nav className="flex flex-wrap gap-2">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="rounded-lg px-3 py-1.5 text-sm text-white/70 hover:bg-white/10 hover:text-white"
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <button onClick={signOut} className="btn-secondary text-sm py-2 px-4">
          Sign Out
        </button>
      </div>
    </header>
  );
}
