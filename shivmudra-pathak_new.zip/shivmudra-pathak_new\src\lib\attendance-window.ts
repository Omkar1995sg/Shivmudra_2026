const IST = "Asia/Kolkata";

export const ATTENDANCE_START_HOUR = 20;
export const ATTENDANCE_START_MINUTE = 30;
export const ATTENDANCE_END_HOUR = 21;
export const ATTENDANCE_END_MINUTE = 30;

export function getISTNow(): Date {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: IST,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(now);

  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "0";
  return new Date(
    `${get("year")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}:${get("second")}`
  );
}

export function getISTDateString(date = getISTNow()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function isWithinAttendanceWindow(now = getISTNow()): boolean {
  const minutes = now.getHours() * 60 + now.getMinutes();
  const start = ATTENDANCE_START_HOUR * 60 + ATTENDANCE_START_MINUTE;
  const end = ATTENDANCE_END_HOUR * 60 + ATTENDANCE_END_MINUTE;
  return minutes >= start && minutes < end;
}

export function getWindowMessage(): string {
  return "उपस्थिती केवळ सायंकाळी ८:३० ते ९:३० पर्यंत | Attendance only 8:30 PM – 9:30 PM IST";
}

export function getMinutesUntilWindowOpens(now = getISTNow()): number | null {
  const minutes = now.getHours() * 60 + now.getMinutes();
  const start = ATTENDANCE_START_HOUR * 60 + ATTENDANCE_START_MINUTE;
  if (minutes < start) return start - minutes;
  return null;
}

export function getMinutesUntilWindowCloses(now = getISTNow()): number | null {
  const minutes = now.getHours() * 60 + now.getMinutes();
  const end = ATTENDANCE_END_HOUR * 60 + ATTENDANCE_END_MINUTE;
  if (minutes >= ATTENDANCE_START_HOUR * 60 + ATTENDANCE_START_MINUTE && minutes < end) {
    return end - minutes;
  }
  return null;
}
