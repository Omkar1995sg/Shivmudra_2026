-- Blood group + Senior/Junior category for members
-- Run in Supabase SQL Editor

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS blood_group TEXT,
  ADD COLUMN IF NOT EXISTS member_category TEXT;

ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_member_category_check;
ALTER TABLE profiles
  ADD CONSTRAINT profiles_member_category_check
  CHECK (member_category IS NULL OR member_category IN ('senior', 'junior'));

CREATE INDEX IF NOT EXISTS idx_profiles_member_category ON profiles(member_category);
