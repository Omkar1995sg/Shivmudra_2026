import { createClient } from "@supabase/supabase-js";

export function getSupabaseConfigError(): string | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() ?? "";
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ?? "";

  if (!url || !serviceKey) {
    return "Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local.";
  }

  if (
    url.includes("your-project.supabase.co") ||
    serviceKey === "your-service-role-key" ||
    serviceKey.startsWith("your-")
  ) {
    return "Supabase still has placeholder values in .env.local. Replace them with your real project URL and service role key from the Supabase dashboard.";
  }

  return null;
}

export function createAdminClient() {
  const configError = getSupabaseConfigError();
  if (configError) {
    throw new Error(configError);
  }

  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
