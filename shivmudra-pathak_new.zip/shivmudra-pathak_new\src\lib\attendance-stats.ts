import {
  INSTRUMENTS,
  instrumentLabel,
  type InstrumentOption,
  type MemberCategory,
} from "@/lib/member-fields";

/** First day of pathak attendance tracking on the admin dashboard. */
export const ATTENDANCE_DASHBOARD_START = "2026-07-27";

export interface MemberForInstrumentStats {
  id: string;
  member_category: string | null;
  instrument: string | null;
}

export interface InstrumentTodayStats {
  instrument: InstrumentOption;
  label: string;
  seniorRegistrations: number;
  seniorPresentToday: number;
  juniorRegistrations: number;
  juniorPresentToday: number;
}

export interface DailyInstrumentAttendance {
  date: string;
  dholSeniorPresent: number;
  dholJuniorPresent: number;
  tashaSeniorPresent: number;
  tashaJuniorPresent: number;
  dhawajSeniorPresent: number;
  dhawajJuniorPresent: number;
  seniorPresentTotal: number;
  juniorPresentTotal: number;
}

function isKnownInstrument(value: string | null | undefined): value is InstrumentOption {
  return INSTRUMENTS.includes(value as InstrumentOption);
}

function countMembers(
  members: MemberForInstrumentStats[],
  instrument: InstrumentOption,
  category: MemberCategory
): number {
  return members.filter(
    (m) => m.member_category === category && m.instrument === instrument
  ).length;
}

function countPresent(
  members: MemberForInstrumentStats[],
  presentIds: Set<string>,
  instrument: InstrumentOption,
  category: MemberCategory
): number {
  return members.filter(
    (m) =>
      m.member_category === category &&
      m.instrument === instrument &&
      presentIds.has(m.id)
  ).length;
}

export function buildInstrumentTodayStats(
  members: MemberForInstrumentStats[],
  presentIds: Set<string>
): InstrumentTodayStats[] {
  return INSTRUMENTS.map((instrument) => ({
    instrument,
    label: instrumentLabel(instrument),
    seniorRegistrations: countMembers(members, instrument, "senior"),
    seniorPresentToday: countPresent(members, presentIds, instrument, "senior"),
    juniorRegistrations: countMembers(members, instrument, "junior"),
    juniorPresentToday: countPresent(members, presentIds, instrument, "junior"),
  }));
}

function emptyDailyRow(date: string): DailyInstrumentAttendance {
  return {
    date,
    dholSeniorPresent: 0,
    dholJuniorPresent: 0,
    tashaSeniorPresent: 0,
    tashaJuniorPresent: 0,
    dhawajSeniorPresent: 0,
    dhawajJuniorPresent: 0,
    seniorPresentTotal: 0,
    juniorPresentTotal: 0,
  };
}

function presentKey(instrument: InstrumentOption, category: MemberCategory): keyof DailyInstrumentAttendance {
  if (instrument === "dhol") return category === "senior" ? "dholSeniorPresent" : "dholJuniorPresent";
  if (instrument === "tasha") return category === "senior" ? "tashaSeniorPresent" : "tashaJuniorPresent";
  return category === "senior" ? "dhawajSeniorPresent" : "dhawajJuniorPresent";
}

export function buildDailyInstrumentAttendance(
  members: MemberForInstrumentStats[],
  attendanceRows: { user_id: string; attendance_date: string }[],
  startDate: string,
  endDate: string
): DailyInstrumentAttendance[] {
  const memberMap = new Map(members.map((m) => [m.id, m]));
  const byDate = new Map<string, DailyInstrumentAttendance>();

  for (const row of attendanceRows) {
    if (row.attendance_date < startDate || row.attendance_date > endDate) continue;

    const member = memberMap.get(row.user_id);
    if (!member?.instrument || !member.member_category) continue;
    if (!isKnownInstrument(member.instrument)) continue;
    if (member.member_category !== "senior" && member.member_category !== "junior") continue;

    const category = member.member_category as MemberCategory;
    const instrument = member.instrument;

    if (!byDate.has(row.attendance_date)) {
      byDate.set(row.attendance_date, emptyDailyRow(row.attendance_date));
    }

    const day = byDate.get(row.attendance_date)!;
    const key = presentKey(instrument, category);
    (day[key] as number) += 1;
    if (category === "senior") day.seniorPresentTotal += 1;
    else day.juniorPresentTotal += 1;
  }

  const dates: string[] = [];
  const cursor = new Date(`${startDate}T12:00:00`);
  const end = new Date(`${endDate}T12:00:00`);
  while (cursor <= end) {
    const y = cursor.getFullYear();
    const m = String(cursor.getMonth() + 1).padStart(2, "0");
    const d = String(cursor.getDate()).padStart(2, "0");
    dates.push(`${y}-${m}-${d}`);
    cursor.setDate(cursor.getDate() + 1);
  }

  return dates
    .map((date) => byDate.get(date) ?? emptyDailyRow(date))
    .reverse();
}

export function formatDashboardDate(isoDate: string): string {
  const [y, m, d] = isoDate.split("-");
  return `${d}/${m}/${y}`;
}
