-- Shivmudra Dhol Tasha Pathak — run in Supabase SQL Editor

CREATE TYPE user_role AS ENUM ('admin', 'leader', 'user');
CREATE TYPE instrument_type AS ENUM ('dhol', 'tasha', 'dhawaj');
CREATE TYPE member_status AS ENUM ('active', 'inactive');
CREATE TYPE request_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE approval_status AS ENUM ('pending', 'approved', 'rejected');

-- Profiles linked to auth.users
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'user',
  status member_status NOT NULL DEFAULT 'inactive',
  approval_status approval_status NOT NULL DEFAULT 'pending',
  name TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  instrument instrument_type,
  reference TEXT NOT NULL DEFAULT '',
  previous_pathak BOOLEAN NOT NULL DEFAULT false,
  previous_pathak_name TEXT,
  photo_url TEXT,
  section TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Practice ground geo-fence (admin sets once)
CREATE TABLE practice_ground (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  center_lat DOUBLE PRECISION NOT NULL,
  center_lng DOUBLE PRECISION NOT NULL,
  radius_meters INTEGER NOT NULL DEFAULT 150,
  name TEXT NOT NULL DEFAULT 'Sarav Ground',
  set_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Daily attendance
CREATE TABLE attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  attendance_date DATE NOT NULL DEFAULT (CURRENT_DATE AT TIME ZONE 'Asia/Kolkata')::date,
  marked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  distance_meters DOUBLE PRECISION,
  geo_verified BOOLEAN NOT NULL DEFAULT false,
  UNIQUE(user_id, attendance_date)
);

-- Leader removal requests
CREATE TABLE removal_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  raised_by UUID NOT NULL REFERENCES profiles(id),
  reason TEXT NOT NULL,
  status request_status NOT NULL DEFAULT 'pending',
  reviewed_by UUID REFERENCES profiles(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Daily report log
CREATE TABLE daily_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_date DATE NOT NULL UNIQUE,
  file_path TEXT,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_attendance_date ON attendance(attendance_date);
CREATE INDEX idx_attendance_user ON attendance(user_id);
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_profiles_instrument ON profiles(instrument);
CREATE INDEX idx_profiles_status ON profiles(status);
CREATE INDEX idx_profiles_approval ON profiles(approval_status);

-- Updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE practice_ground ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE removal_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;

-- Helper: current user role
CREATE OR REPLACE FUNCTION get_my_role()
RETURNS user_role AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Profiles policies
CREATE POLICY "Users read own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admin read all profiles" ON profiles
  FOR SELECT USING (get_my_role() = 'admin');

CREATE POLICY "Leader read active members" ON profiles
  FOR SELECT USING (
    get_my_role() = 'leader'
    AND status = 'active'
    AND approval_status = 'approved'
  );

CREATE POLICY "Admin insert profiles" ON profiles
  FOR INSERT WITH CHECK (get_my_role() = 'admin');

CREATE POLICY "Admin update profiles" ON profiles
  FOR UPDATE USING (get_my_role() = 'admin');

CREATE POLICY "Users update own limited" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Practice ground
CREATE POLICY "Everyone read ground" ON practice_ground
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admin manage ground" ON practice_ground
  FOR ALL USING (get_my_role() = 'admin');

-- Attendance
CREATE POLICY "Users read own attendance" ON attendance
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admin leader read attendance" ON attendance
  FOR SELECT USING (get_my_role() IN ('admin', 'leader'));

CREATE POLICY "Users insert own attendance" ON attendance
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Removal requests
CREATE POLICY "Leader create requests" ON removal_requests
  FOR INSERT WITH CHECK (get_my_role() IN ('leader', 'admin') AND raised_by = auth.uid());

CREATE POLICY "Leader read own requests" ON removal_requests
  FOR SELECT USING (raised_by = auth.uid() OR get_my_role() = 'admin');

CREATE POLICY "Admin update requests" ON removal_requests
  FOR UPDATE USING (get_my_role() = 'admin');

-- Daily reports — admin only
CREATE POLICY "Admin read reports" ON daily_reports
  FOR SELECT USING (get_my_role() = 'admin');

-- Storage: create bucket "member-photos" in Dashboard (public)
-- Then run:
-- CREATE POLICY "Public read photos" ON storage.objects FOR SELECT USING (bucket_id = 'member-photos');
-- CREATE POLICY "Admin upload photos" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'member-photos' AND auth.role() = 'authenticated');

-- Bootstrap function: set admin on first signup for bootstrap email
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  bootstrap_email TEXT := 'omkargavkhadkar@gmail.com';
  assigned_role user_role := 'user';
  member_status_val member_status := 'inactive';
  approval_val approval_status := 'pending';
BEGIN
  IF NEW.email = bootstrap_email THEN
    assigned_role := 'admin';
    member_status_val := 'active';
    approval_val := 'approved';
  END IF;

  INSERT INTO profiles (id, email, role, name, status, approval_status)
  VALUES (
    NEW.id,
    NEW.email,
    assigned_role,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    member_status_val,
    approval_val
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Seed single practice ground row (Pune default — admin updates on map)
INSERT INTO practice_ground (center_lat, center_lng, radius_meters, name)
VALUES (18.5204, 73.8567, 150, 'Shivmudra Sarav Ground');
