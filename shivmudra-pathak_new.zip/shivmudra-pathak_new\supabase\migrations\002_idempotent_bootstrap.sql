-- Safe to re-run on a partially initialized Shivmudra Supabase project.
-- Use this when schema.sql fails with "type already exists".

DO $$ BEGIN CREATE TYPE user_role AS ENUM ('admin', 'leader', 'user');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE instrument_type AS ENUM ('dhol', 'tasha', 'dhawaj');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE member_status AS ENUM ('active', 'inactive');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE request_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE approval_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'user',
  status member_status NOT NULL DEFAULT 'inactive',
  approval_status approval_status NOT NULL DEFAULT 'pending',
  name TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  instrument instrument_type,
  reference TEXT NOT NULL DEFAULT '',
  previous_pathak BOOLEAN NOT NULL DEFAULT false,
  previous_pathak_name TEXT,
  photo_url TEXT,
  section TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS approval_status approval_status NOT NULL DEFAULT 'pending';

CREATE TABLE IF NOT EXISTS practice_ground (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  center_lat DOUBLE PRECISION NOT NULL,
  center_lng DOUBLE PRECISION NOT NULL,
  radius_meters INTEGER NOT NULL DEFAULT 150,
  name TEXT NOT NULL DEFAULT 'Sarav Ground',
  set_by UUID REFERENCES profiles(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  attendance_date DATE NOT NULL DEFAULT (CURRENT_DATE AT TIME ZONE 'Asia/Kolkata')::date,
  marked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  distance_meters DOUBLE PRECISION,
  geo_verified BOOLEAN NOT NULL DEFAULT false,
  UNIQUE(user_id, attendance_date)
);

CREATE TABLE IF NOT EXISTS removal_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  raised_by UUID NOT NULL REFERENCES profiles(id),
  reason TEXT NOT NULL,
  status request_status NOT NULL DEFAULT 'pending',
  reviewed_by UUID REFERENCES profiles(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS daily_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_date DATE NOT NULL UNIQUE,
  file_path TEXT,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date);
CREATE INDEX IF NOT EXISTS idx_attendance_user ON attendance(user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_instrument ON profiles(instrument);
CREATE INDEX IF NOT EXISTS idx_profiles_status ON profiles(status);
CREATE INDEX IF NOT EXISTS idx_profiles_approval ON profiles(approval_status);

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE practice_ground ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE removal_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION get_my_role()
RETURNS user_role AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

DROP POLICY IF EXISTS "Users read own profile" ON profiles;
CREATE POLICY "Users read own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Admin read all profiles" ON profiles;
CREATE POLICY "Admin read all profiles" ON profiles
  FOR SELECT USING (get_my_role() = 'admin');

DROP POLICY IF EXISTS "Leader read active members" ON profiles;
CREATE POLICY "Leader read active members" ON profiles
  FOR SELECT USING (
    get_my_role() = 'leader'
    AND status = 'active'
    AND approval_status = 'approved'
  );

DROP POLICY IF EXISTS "Admin insert profiles" ON profiles;
CREATE POLICY "Admin insert profiles" ON profiles
  FOR INSERT WITH CHECK (get_my_role() = 'admin');

DROP POLICY IF EXISTS "Admin update profiles" ON profiles;
CREATE POLICY "Admin update profiles" ON profiles
  FOR UPDATE USING (get_my_role() = 'admin');

DROP POLICY IF EXISTS "Users update own limited" ON profiles;
CREATE POLICY "Users update own limited" ON profiles
  FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Everyone read ground" ON practice_ground;
CREATE POLICY "Everyone read ground" ON practice_ground
  FOR SELECT USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Admin manage ground" ON practice_ground;
CREATE POLICY "Admin manage ground" ON practice_ground
  FOR ALL USING (get_my_role() = 'admin');

DROP POLICY IF EXISTS "Users read own attendance" ON attendance;
CREATE POLICY "Users read own attendance" ON attendance
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admin leader read attendance" ON attendance;
CREATE POLICY "Admin leader read attendance" ON attendance
  FOR SELECT USING (get_my_role() IN ('admin', 'leader'));

DROP POLICY IF EXISTS "Users insert own attendance" ON attendance;
CREATE POLICY "Users insert own attendance" ON attendance
  FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Leader create requests" ON removal_requests;
CREATE POLICY "Leader create requests" ON removal_requests
  FOR INSERT WITH CHECK (get_my_role() IN ('leader', 'admin') AND raised_by = auth.uid());

DROP POLICY IF EXISTS "Leader read own requests" ON removal_requests;
CREATE POLICY "Leader read own requests" ON removal_requests
  FOR SELECT USING (raised_by = auth.uid() OR get_my_role() = 'admin');

DROP POLICY IF EXISTS "Admin update requests" ON removal_requests;
CREATE POLICY "Admin update requests" ON removal_requests
  FOR UPDATE USING (get_my_role() = 'admin');

DROP POLICY IF EXISTS "Admin read reports" ON daily_reports;
CREATE POLICY "Admin read reports" ON daily_reports
  FOR SELECT USING (get_my_role() = 'admin');

-- Critical: auto-create profile row when auth user is created
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  bootstrap_email TEXT := 'omkargavkhadkar@gmail.com';
  assigned_role user_role := 'user';
  member_status_val member_status := 'inactive';
  approval_val approval_status := 'pending';
BEGIN
  IF NEW.email = bootstrap_email THEN
    assigned_role := 'admin';
    member_status_val := 'active';
    approval_val := 'approved';
  END IF;

  INSERT INTO profiles (id, email, role, name, status, approval_status)
  VALUES (
    NEW.id,
    NEW.email,
    assigned_role,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    member_status_val,
    approval_val
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

INSERT INTO practice_ground (center_lat, center_lng, radius_meters, name)
SELECT 18.5204, 73.8567, 150, 'Shivmudra Sarav Ground'
WHERE NOT EXISTS (SELECT 1 FROM practice_ground LIMIT 1);

UPDATE profiles
SET approval_status = 'approved'
WHERE approval_status IS DISTINCT FROM 'approved'
  AND (role IN ('admin', 'leader') OR (role = 'user' AND status = 'active'));
