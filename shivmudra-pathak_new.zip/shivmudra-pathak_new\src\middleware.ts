import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import type { User } from "@supabase/supabase-js";

function unauthorizedApi() {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

async function safeGetUser(
  supabase: ReturnType<typeof createServerClient>
): Promise<User | null> {
  try {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();
    if (error) {
      console.error("[middleware] getUser error:", error.message);
      return null;
    }
    return user;
  } catch (err) {
    // Corporate TLS / network can break Edge fetch to Supabase.
    console.error("[middleware] getUser failed:", err);
    return null;
  }
}

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  const user = await safeGetUser(supabase);

  const path = request.nextUrl.pathname;
  const isApi = path.startsWith("/api/");
  const cronAuth = request.headers.get("authorization");
  const isCronReport =
    path === "/api/reports/generate" &&
    cronAuth === `Bearer ${process.env.CRON_SECRET}`;
  const isPublic =
    path === "/login" ||
    path.startsWith("/login/") ||
    path === "/register" ||
    path.startsWith("/register/") ||
    path === "/attendance" ||
    path.startsWith("/attendance/") ||
    path === "/user/senior" ||
    path === "/user/junior" ||
    path === "/auth/callback" ||
    path === "/api/registration" ||
    path.startsWith("/api/cron") ||
    isCronReport;

  // Auth cookie present but getUser failed (TLS/network): do not bounce protected pages to login.
  const hasAuthCookie = request.cookies
    .getAll()
    .some((c) => c.name.includes("auth-token") || c.name.includes("sb-"));

  if (!user && !isPublic && path !== "/") {
    if (hasAuthCookie && !isApi) {
      // Let the page load; server components can re-validate the session.
      return supabaseResponse;
    }
    if (isApi) return unauthorizedApi();
    let loginPath = "/login";
    if (path.startsWith("/user/senior")) loginPath = "/login/senior";
    else if (path.startsWith("/user/junior")) loginPath = "/login/junior";
    return NextResponse.redirect(new URL(loginPath, request.url));
  }

  if (user && path === "/login") {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role, member_category")
      .eq("id", user.id)
      .single();

    const role = profile?.role ?? "user";
    if (role === "admin") return NextResponse.redirect(new URL("/admin", request.url));
    if (role === "leader") return NextResponse.redirect(new URL("/leader", request.url));
    if (profile?.member_category === "senior" || profile?.member_category === "junior") {
      return NextResponse.redirect(new URL(`/user/${profile.member_category}`, request.url));
    }
    return NextResponse.redirect(new URL("/attendance", request.url));
  }

  if (user && (path === "/login/senior" || path === "/login/junior")) {
    const category = path.endsWith("/junior") ? "junior" : "senior";
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();
    const role = profile?.role ?? "user";
    if (role === "admin") {
      return NextResponse.redirect(new URL(`/admin/${category}`, request.url));
    }
    return NextResponse.redirect(new URL(`/user/${category}`, request.url));
  }

  if (user && (path === "/attendance" || path.startsWith("/attendance/"))) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role, member_category")
      .eq("id", user.id)
      .single();
    const role = profile?.role ?? "user";
    if (role === "admin") {
      const segment = path.split("/")[2];
      if (segment === "senior" || segment === "junior") {
        return NextResponse.redirect(new URL(`/admin/${segment}`, request.url));
      }
      return NextResponse.redirect(new URL("/admin", request.url));
    }
    if (role === "user" && profile?.member_category) {
      return NextResponse.redirect(new URL(`/user/${profile.member_category}`, request.url));
    }
    return NextResponse.redirect(new URL("/user", request.url));
  }

  if (user && !isApi) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();
    const role = profile?.role ?? "user";

    if (path.startsWith("/admin") && role !== "admin") {
      return NextResponse.redirect(new URL(role === "leader" ? "/leader" : "/user", request.url));
    }
    if (path.startsWith("/leader") && role !== "leader" && role !== "admin") {
      return NextResponse.redirect(new URL("/user", request.url));
    }
    const isCategoryPortal = path === "/user/senior" || path === "/user/junior";
    if (path.startsWith("/user") && role === "admin" && !isCategoryPortal) {
      return NextResponse.redirect(new URL("/admin", request.url));
    }
    if (path.startsWith("/user") && role === "leader" && !isCategoryPortal) {
      return NextResponse.redirect(new URL("/leader", request.url));
    }
  }

  return supabaseResponse;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
