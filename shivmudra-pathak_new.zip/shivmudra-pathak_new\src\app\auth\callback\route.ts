import { NextResponse } from "next/server";
import {
  getLoginPathForContext,
  getPostLoginPath,
  getRegisterPathForCategory,
  isGmailEmail,
  isMemberCategory,
  type LoginContext,
} from "@/lib/auth-redirect";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const category = searchParams.get("category");
  const contextParam = searchParams.get("context");
  const flow = searchParams.get("flow");

  const isRegisterFlow = flow === "register";
  const memberCategory = isMemberCategory(category) ? category : "senior";

  const context: LoginContext =
    contextParam === "admin"
      ? "admin"
      : category === "junior"
        ? "junior"
        : category === "senior"
          ? "senior"
          : "admin";

  const errorPath = isRegisterFlow
    ? getRegisterPathForCategory(memberCategory)
    : getLoginPathForContext(context);

  if (!code) {
    return NextResponse.redirect(`${origin}${errorPath}?error=auth`);
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.exchangeCodeForSession(code);

  if (error) {
    return NextResponse.redirect(`${origin}${errorPath}?error=auth`);
  }

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user?.email) {
    await supabase.auth.signOut();
    return NextResponse.redirect(`${origin}${errorPath}?error=auth`);
  }

  if (!isGmailEmail(user.email)) {
    await supabase.auth.signOut();
    return NextResponse.redirect(`${origin}${errorPath}?error=gmail_only`);
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role, member_category, approval_status, phone, instrument")
    .eq("id", user.id)
    .single();

  if (isRegisterFlow) {
    const registerPath = getRegisterPathForCategory(memberCategory);

    if (profile?.approval_status === "approved") {
      const path = getPostLoginPath(profile.role ?? "user", profile.member_category, memberCategory);
      return NextResponse.redirect(`${origin}${path}`);
    }

    if (profile?.approval_status === "pending" && profile.phone && profile.instrument) {
      return NextResponse.redirect(`${origin}${registerPath}?error=already_submitted`);
    }

    return NextResponse.redirect(`${origin}${registerPath}`);
  }

  const path = getPostLoginPath(profile?.role ?? "user", profile?.member_category, context);
  return NextResponse.redirect(`${origin}${path}`);
}
