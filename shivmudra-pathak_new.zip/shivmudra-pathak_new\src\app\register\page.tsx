import Link from "next/link";
import { BrandingHeader } from "@/components/BrandingHeader";

/** Optional entry — share /register/senior or /register/junior directly */
export default function RegisterHubPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col justify-center p-6">
      <BrandingHeader compact />
      <p className="mt-6 text-center text-sm text-white/60">
        Select your dedicated registration link
      </p>
      <div className="mt-6 grid gap-3">
        <Link href="/register/senior" className="btn-primary text-center">
          Senior Registration → /register/senior
        </Link>
        <Link href="/register/junior" className="btn-primary text-center">
          Junior Registration → /register/junior
        </Link>
      </div>
      <p className="mt-6 text-center text-sm text-white/50">
        <Link href="/login" className="text-brand-500 hover:underline">
          Sign In
        </Link>
      </p>
    </main>
  );
}
