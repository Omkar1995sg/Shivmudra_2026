"""Clean + emboss Shivmudra logo from Image (3).jpg."""
from PIL import Image, ImageFilter, ImageEnhance
import numpy as np
from collections import deque

SRC = r"C:\Users\omkarga\Downloads\Image (3).jpg"
OUT_PNG = r"C:\Users\omkarga\OneDrive - AMDOCS\Desktop\gandalf\archetypes-collection\shivmudra-pathak\public\branding\logo.png"


def flood_white_bg(r, g, b, threshold=235):
    h, w = r.shape
    visited = np.zeros((h, w), dtype=bool)
    bg = np.zeros((h, w), dtype=bool)

    def is_white(y, x):
        return r[y, x] > threshold and g[y, x] > threshold and b[y, x] > threshold

    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if is_white(y, x):
                q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if is_white(y, x):
                q.append((y, x))

    while q:
        y, x = q.popleft()
        if y < 0 or y >= h or x < 0 or x >= w or visited[y, x]:
            continue
        if not is_white(y, x):
            continue
        visited[y, x] = True
        bg[y, x] = True
        q.extend([(y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)])
    return bg


def erode_white_fringe(alpha, r, g, b, passes=4):
    h, w = alpha.shape
    a = alpha.copy()
    bright = (r > 222) & (g > 222) & (b > 222)
    for _ in range(passes):
        clear = np.zeros((h, w), dtype=bool)
        for y in range(h):
            for x in range(w):
                if a[y, x] < 128 or not bright[y, x]:
                    continue
                for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    ny, nx = y + dy, x + dx
                    if ny < 0 or ny >= h or nx < 0 or nx >= w or a[ny, nx] < 128:
                        clear[y, x] = True
                        break
        a[clear] = 0
    return a


img = Image.open(SRC).convert("RGBA")
w, h = img.size
crop = img.crop((int(w * 0.14), int(h * 0.06), int(w * 0.86), int(h * 0.72)))

arr = np.array(crop, dtype=np.float32)
r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
bg = flood_white_bg(r, g, b, threshold=234)
alpha = np.where(bg, 0, 255).astype(np.uint8)
alpha = erode_white_fringe(alpha, r, g, b, passes=5)

out = np.dstack([r, g, b, alpha]).astype(np.uint8)
result = Image.fromarray(out)

bbox = result.getbbox()
if bbox:
    result = result.crop(bbox)

# Subtle baked emboss on RGB (keeps alpha)
r, g, b, a = result.split()
rgb = Image.merge("RGB", (r, g, b))
emboss = rgb.filter(ImageFilter.EMBOSS)
blended = Image.blend(rgb, emboss, 0.28)
blended = ImageEnhance.Contrast(blended).enhance(1.12)
blended = ImageEnhance.Sharpness(blended).enhance(1.15)
result = Image.merge("RGBA", (*blended.split(), a))

rw, rh = result.size
side = max(rw, rh)
pad = max(4, int(side * 0.02))
canvas = Image.new("RGBA", (side + pad * 2, side + pad * 2), (0, 0, 0, 0))
canvas.paste(result, (pad + (side - rw) // 2, pad + (side - rh) // 2))
result = canvas.resize((512, 512), Image.Resampling.LANCZOS)
result.save(OUT_PNG)
print("Saved", OUT_PNG, result.size)
