import { CategoryAdminDashboard } from "@/components/CategoryAdminDashboard";

export default function JuniorAdminDashboard() {
  return <CategoryAdminDashboard category="junior" />;
}
