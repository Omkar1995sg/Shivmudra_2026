import { CategoryAdminDashboard } from "@/components/CategoryAdminDashboard";

export default function SeniorAdminDashboard() {
  return <CategoryAdminDashboard category="senior" />;
}
