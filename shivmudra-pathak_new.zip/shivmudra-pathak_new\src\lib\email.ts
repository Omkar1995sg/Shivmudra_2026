/**
 * Transactional email via Resend (https://resend.com).
 * Set RESEND_API_KEY and FROM_EMAIL in .env.local — skips silently if unset.
 */

const FROM = process.env.FROM_EMAIL ?? "Shivmudra Pathak <onboarding@resend.dev>";

export async function sendRegistrationApprovedEmail(
  to: string,
  name: string
): Promise<{ sent: boolean; error?: string }> {
  const subject = "शिवमुद्रा पथक — Registration Approved";
  const html = `
    <p>नमस्कार ${name},</p>
    <p>Your registration with <strong>Shivmudra Dhol Tasha Pathak</strong> has been <strong>approved</strong>.</p>
    <p>You can now sign in and mark daily attendance during practice hours (8:30–9:30 PM IST) at the sarav ground.</p>
    <p>॥ जय शिवराय ॥</p>
  `;
  return sendEmail(to, subject, html);
}

export async function sendRegistrationRejectedEmail(
  to: string,
  name: string
): Promise<{ sent: boolean; error?: string }> {
  const subject = "शिवमुद्रा पथक — Registration Update";
  const html = `
    <p>नमस्कार ${name},</p>
    <p>Thank you for your interest in <strong>Shivmudra Dhol Tasha Pathak</strong>.</p>
    <p>Your registration request was not approved at this time. Please contact the pathak management for details.</p>
  `;
  return sendEmail(to, subject, html);
}

async function sendEmail(
  to: string,
  subject: string,
  html: string
): Promise<{ sent: boolean; error?: string }> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.info("[email] RESEND_API_KEY not set — would send to", to, subject);
    return { sent: false, error: "RESEND_API_KEY not configured" };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: FROM, to: [to], subject, html }),
    });

    if (!res.ok) {
      const body = await res.text();
      console.error("[email] Resend error:", body);
      return { sent: false, error: body };
    }

    return { sent: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[email] send failed:", msg);
    return { sent: false, error: msg };
  }
}
