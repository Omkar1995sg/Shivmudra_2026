import ExcelJS from "exceljs";
import { getISTDateString } from "./attendance-window";
import { countAttendanceByCategory, categoryLabel, instrumentLabel } from "./member-fields";
import type { Profile, Attendance } from "@/types/database";

const CONSECUTIVE_ABSENT_THRESHOLD = 5;

function sheetHeaders(sheet: ExcelJS.Worksheet) {
  sheet.columns = [
    { header: "Name", key: "name", width: 25 },
    { header: "Category", key: "category", width: 12 },
    { header: "Phone", key: "phone", width: 15 },
    { header: "Blood Group", key: "blood_group", width: 12 },
    { header: "Instrument", key: "instrument", width: 12 },
    { header: "Status Today", key: "status", width: 14 },
    { header: "Marked At", key: "marked_at", width: 22 },
    { header: "Geo Verified", key: "geo", width: 14 },
    { header: "Distance (m)", key: "distance", width: 14 },
  ];
  sheet.getRow(1).font = { bold: true };
}

function buildRows(
  members: Profile[],
  attendanceMap: Map<string, Attendance>,
  date: string
) {
  return members.map((m) => {
    const att = attendanceMap.get(m.id);
    return {
      name: m.name,
      category: categoryLabel(m.member_category),
      phone: m.phone,
      blood_group: m.blood_group ?? "-",
      instrument: instrumentLabel(m.instrument),
      status: att ? "Present" : "Absent",
      marked_at: att?.marked_at
        ? new Date(att.marked_at).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })
        : "-",
      geo: att?.geo_verified ? "Yes" : att ? "No" : "-",
      distance: att?.distance_meters ?? "-",
      date,
    };
  });
}

export function getConsecutiveAbsentDays(
  userId: string,
  allAttendance: Attendance[],
  today: string
): number {
  const userDates = new Set(
    allAttendance.filter((a) => a.user_id === userId).map((a) => a.attendance_date)
  );

  let streak = 0;
  const d = new Date(today + "T00:00:00");
  for (let i = 0; i < 30; i++) {
    const ds = d.toISOString().slice(0, 10);
    if (userDates.has(ds)) break;
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

function addCategorySheet(
  workbook: ExcelJS.Workbook,
  title: string,
  members: Profile[],
  attMap: Map<string, Attendance>,
  today: string
) {
  const sheet = workbook.addWorksheet(title);
  sheetHeaders(sheet);
  buildRows(members, attMap, today).forEach((r) => sheet.addRow(r));
}

export async function generateDailyReport(
  members: Profile[],
  todayAttendance: Attendance[],
  recentAttendance: Attendance[],
  today: string = getISTDateString()
): Promise<Buffer> {
  const active = members.filter((m) => m.status === "active" && m.approval_status === "approved");
  const attMap = new Map(todayAttendance.map((a) => [a.user_id, a]));
  const presentIds = new Set(todayAttendance.map((a) => a.user_id));
  const stats = countAttendanceByCategory(active, presentIds);

  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Shivmudra Dhol Tasha Pathak";

  const summary = workbook.addWorksheet("Summary");
  summary.columns = [
    { header: "Metric", key: "metric", width: 28 },
    { header: "Count", key: "count", width: 12 },
  ];
  summary.getRow(1).font = { bold: true };
  summary.addRows([
    { metric: "Report Date", count: today },
    { metric: "Total Active Members", count: stats.total },
    { metric: "Total Present Today", count: stats.totalPresent },
    { metric: "Senior Members", count: stats.seniorTotal },
    { metric: "Senior Present Today", count: stats.seniorPresent },
    { metric: "Junior Members", count: stats.juniorTotal },
    { metric: "Junior Present Today", count: stats.juniorPresent },
  ]);

  addCategorySheet(workbook, "Global Attendance", active, attMap, today);
  addCategorySheet(
    workbook,
    "Senior Attendance",
    active.filter((m) => m.member_category === "senior"),
    attMap,
    today
  );
  addCategorySheet(
    workbook,
    "Junior Attendance",
    active.filter((m) => m.member_category === "junior"),
    attMap,
    today
  );

  const instrumentSheets = [
    { value: "dhol" as const, label: "Dhol-Dhwaj Attendance" },
    { value: "tasha" as const, label: "Tasha-Dhwaj Attendance" },
    { value: "dhawaj" as const, label: "Dhwaj Attendance" },
  ];
  for (const inst of instrumentSheets) {
    addCategorySheet(
      workbook,
      inst.label,
      active.filter((m) => m.instrument === inst.value),
      attMap,
      today
    );
  }

  const defaulters = workbook.addWorksheet("Defaulters");
  defaulters.columns = [
    { header: "Name", key: "name", width: 25 },
    { header: "Category", key: "category", width: 12 },
    { header: "Phone", key: "phone", width: 15 },
    { header: "Blood Group", key: "blood_group", width: 12 },
    { header: "Instrument", key: "instrument", width: 12 },
    { header: "Consecutive Absent Days", key: "streak", width: 22 },
    { header: "Status", key: "status", width: 12 },
  ];
  defaulters.getRow(1).font = { bold: true };

  active.forEach((m) => {
    const streak = getConsecutiveAbsentDays(m.id, recentAttendance, today);
    const absentToday = !attMap.has(m.id);
    if (streak >= CONSECUTIVE_ABSENT_THRESHOLD || m.status === "inactive") {
      defaulters.addRow({
        name: m.name,
        category: categoryLabel(m.member_category),
        phone: m.phone,
        blood_group: m.blood_group ?? "-",
        instrument: instrumentLabel(m.instrument),
        streak,
        status: m.status === "inactive" ? "Inactive" : absentToday ? "Absent" : "Present",
      });
    } else if (absentToday && streak >= CONSECUTIVE_ABSENT_THRESHOLD - 1) {
      defaulters.addRow({
        name: m.name,
        category: categoryLabel(m.member_category),
        phone: m.phone,
        blood_group: m.blood_group ?? "-",
        instrument: instrumentLabel(m.instrument),
        streak: streak + 1,
        status: "Absent",
      });
    }
  });

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}
