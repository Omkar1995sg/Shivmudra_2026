"""Crop Shivmudra octagon logo and remove white/light background."""
from PIL import Image
import numpy as np
import sys


def remove_light_bg(crop: Image.Image) -> Image.Image:
    carr = np.array(crop, dtype=np.float32)
    r, g, b = carr[:, :, 0], carr[:, :, 1], carr[:, :, 2]
    brightness = (r + g + b) / 3.0
    maxc = np.maximum(np.maximum(r, g), b)
    minc = np.minimum(np.minimum(r, g), b)
    sat = maxc - minc

    alpha = np.full(carr.shape[:2], 255.0)
    # Only remove near-white / very light UI background
    bg = (r > 238) & (g > 238) & (b > 238)
    bg |= (r > 230) & (g > 225) & (b > 215) & (sat < 25)
    bg |= (brightness > 245)
    alpha[bg] = 0

    # Remove stray fragments in bottom strip only (faded photo leftovers)
    h, w = carr.shape[:2]
    bottom = int(h * 0.72)
    stray = (brightness > 190) & (alpha > 0)
    stray[:bottom, :] = False
    alpha[stray] = 0

    out = np.dstack([r, g, b, alpha]).astype(np.uint8)
    return Image.fromarray(out)


def finalize(result: Image.Image, out_png: str, out_jpg: str) -> Image.Image:
    bbox = result.getbbox()
    if bbox:
        result = result.crop(bbox)

    w, h = result.size
    side = max(w, h)
    pad = int(side * 0.08)
    canvas = Image.new("RGBA", (side + pad * 2, side + pad * 2), (0, 0, 0, 0))
    canvas.paste(result, (pad + (side - w) // 2, pad + (side - h) // 2))
    result = canvas.resize((512, 512), Image.Resampling.LANCZOS)
    result.save(out_png)

    rgb = Image.new("RGB", result.size, (255, 255, 255))
    rgb.paste(result, mask=result.split()[3])
    rgb.save(out_jpg, quality=95)
    return result


def process_screenshot(src: str, out_png: str, out_jpg: str) -> None:
    img = Image.open(src).convert("RGBA")
    w, h = img.size
    # Sharp logo is centered in mobile screenshot
    side = int(min(w, h) * 0.58)
    cx, cy = w // 2, int(h * 0.50)
    crop = img.crop((cx - side // 2, cy - side // 2, cx + side // 2, cy + side // 2))
    result = remove_light_bg(crop)
    finalize(result, out_png, out_jpg)
    print(f"Screenshot -> {out_png}")


def process_download(src: str, out_png: str, out_jpg: str) -> None:
    img = Image.open(src).convert("RGBA")
    arr = np.array(img, dtype=np.float32)
    r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]

    # Orange/bronze octagon border and fill
    octagon = (r > 90) & (r < 240) & (g > 40) & (g < 200) & (b < 160) & ((r - g) > 20)
    # White text inside
    octagon |= (r > 210) & (g > 210) & (b > 210)

    ys, xs = np.where(octagon)
    if len(xs) < 50:
        raise RuntimeError("octagon not detected")

    # Prefer upper logo (not faded watermark lower in image)
    h = arr.shape[0]
    upper = octagon.copy()
    upper[int(h * 0.55) :, :] = False
    ys2, xs2 = np.where(upper)
    if len(xs2) > 50:
        ys, xs = ys2, xs2

    margin = 12
    x0, x1 = max(0, int(xs.min()) - margin), min(img.width, int(xs.max()) + margin)
    y0, y1 = max(0, int(ys.min()) - margin), min(img.height, int(ys.max()) + margin)
    crop = img.crop((x0, y0, x1, y1))
    result = remove_light_bg(crop)
    finalize(result, out_png, out_jpg)
    print(f"Download -> {out_png} crop=({x0},{y0},{x1},{y1})")


if __name__ == "__main__":
    src = sys.argv[1]
    out_dir = r"C:\Users\omkarga\OneDrive - AMDOCS\Desktop\gandalf\archetypes-collection\shivmudra-pathak\public\branding"
    out_png = f"{out_dir}/logo.png"
    out_jpg = f"{out_dir}/logo.jpg"

    if "Image (4)" in src or src.lower().endswith(".jpg"):
        process_download(src, out_png, out_jpg)
    else:
        process_screenshot(src, out_png, out_jpg)
