"use client";

import { AppNav } from "@/components/AppNav";
import { instrumentLabel } from "@/lib/member-fields";
import { useEffect, useState } from "react";

interface RequestRow {
  id: string;
  reason: string;
  status: string;
  created_at: string;
  user: { name: string; phone: string; instrument: string };
  leader: { name: string };
}

export default function AdminRequestsPage() {
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  function load() {
    setLoading(true);
    setError("");
    fetch("/api/removal-requests/list")
      .then(async (r) => {
        const data = await r.json();
        if (!r.ok) {
          const msg =
            r.status === 403
              ? "Admin access required. Sign in with your admin account (omkargavkhadkar@gmail.com)."
              : (data.error ?? "Failed to load requests");
          setError(msg);
          setRequests([]);
          return;
        }
        setRequests(Array.isArray(data) ? data : []);
      })
      .catch(() => {
        setError("Failed to load requests");
        setRequests([]);
      })
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  async function review(requestId: string, action: "approved" | "rejected") {
    const res = await fetch("/api/removal-requests", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ request_id: requestId, action }),
    });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error ?? "Failed to review request");
      return;
    }
    setRequests((r) =>
      r.map((x) => (x.id === requestId ? { ...x, status: action } : x))
    );
  }

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-3xl p-6">
        <h1 className="mb-6 text-2xl font-bold text-white">Removal Requests</h1>
        {error && <p className="mb-4 text-sm text-red-400">{error}</p>}
        {loading && <p className="text-white/50">Loading...</p>}
        <div className="space-y-4">
          {requests.map((req) => (
            <div key={req.id} className="card">
              <div className="flex justify-between">
                <div>
                  <p className="font-semibold text-white">{req.user?.name}</p>
                  <p className="text-sm text-white/50">{instrumentLabel(req.user?.instrument)}</p>
                  <p className="mt-2 text-sm text-white/70">{req.reason}</p>
                  <p className="mt-1 text-xs text-white/40">
                    Raised by {req.leader?.name} • {new Date(req.created_at).toLocaleDateString("en-IN")}
                  </p>
                </div>
                <span
                  className={`h-fit rounded-full px-3 py-1 text-xs capitalize ${
                    req.status === "pending"
                      ? "bg-yellow-500/20 text-yellow-300"
                      : req.status === "approved"
                        ? "bg-green-500/20 text-green-300"
                        : "bg-red-500/20 text-red-300"
                  }`}
                >
                  {req.status}
                </span>
              </div>
              {req.status === "pending" && (
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => review(req.id, "approved")}
                    className="btn-primary text-sm py-2"
                  >
                    Approve & Remove
                  </button>
                  <button
                    onClick={() => review(req.id, "rejected")}
                    className="btn-secondary text-sm py-2"
                  >
                    Reject
                  </button>
                </div>
              )}
            </div>
          ))}
          {requests.length === 0 && !loading && !error && (
            <p className="text-white/50">No requests yet.</p>
          )}
        </div>
      </main>
    </>
  );
}
