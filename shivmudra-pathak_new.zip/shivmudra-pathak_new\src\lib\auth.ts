import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import type { Profile, UserRole } from "@/types/database";

export async function getSessionProfile(): Promise<Profile | null> {
  try {
    const supabase = await createClient();
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();
    if (error || !user) return null;

    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single();

    return data as Profile | null;
  } catch (err) {
    console.error("[auth] getSessionProfile failed:", err);
    return null;
  }
}

export async function requireRole(allowed: UserRole[]): Promise<Profile> {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");
  if (!allowed.includes(profile.role)) {
    redirect(profile.role === "admin" ? "/admin" : profile.role === "leader" ? "/leader" : "/user");
  }
  return profile;
}

export function roleDashboard(role: UserRole, memberCategory?: string | null): string {
  switch (role) {
    case "admin":
      return "/admin";
    case "leader":
      return "/leader";
    default:
      if (memberCategory === "senior" || memberCategory === "junior") {
        return `/user/${memberCategory}`;
      }
      return "/user";
  }
}
