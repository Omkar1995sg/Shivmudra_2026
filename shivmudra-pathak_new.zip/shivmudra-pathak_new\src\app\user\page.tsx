import { redirect } from "next/navigation";
import { getSessionProfile } from "@/lib/auth";

export default async function UserPortalLandingPage() {
  const profile = await getSessionProfile();
  if (profile?.member_category === "senior" || profile?.member_category === "junior") {
    redirect(`/user/${profile.member_category}`);
  }
  redirect("/attendance");
}
