"use client";

import Image from "next/image";
import type { Profile } from "@/types/database";
import { instrumentLabel } from "@/lib/member-fields";

export function MemberCard({ member }: { member: Profile }) {
  return (
    <div className="card flex flex-col items-center text-center">
      <div className="relative mb-3 h-24 w-24 overflow-hidden rounded-full border-2 border-brand-500/50 bg-white/10">
        {member.photo_url ? (
          <Image src={member.photo_url} alt={member.name} fill className="object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-3xl text-white/30">
            {member.name.charAt(0)}
          </div>
        )}
      </div>
      <h3 className="font-semibold text-white">{member.name}</h3>
      <p className="text-sm text-brand-500">{instrumentLabel(member.instrument)}</p>
      <p className="mt-2 text-xs text-white/50">{member.phone}</p>
      <p className="text-xs text-white/40">{member.address}</p>
      {member.previous_pathak && (
        <p className="mt-1 text-xs text-white/50">Prev: {member.previous_pathak_name || "Yes"}</p>
      )}
      <span
        className={`mt-2 rounded-full px-2 py-0.5 text-xs ${
          member.status === "active" ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"
        }`}
      >
        {member.status}
      </span>
    </div>
  );
}
