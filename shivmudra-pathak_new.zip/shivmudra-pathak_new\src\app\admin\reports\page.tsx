"use client";

import { AppNav } from "@/components/AppNav";
import { getISTDateString } from "@/lib/attendance-window";

export default function ReportsPage() {
  const today = getISTDateString();

  function downloadReport() {
    window.open(`/api/reports/generate?date=${today}`, "_blank");
  }

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-2xl p-6">
        <h1 className="mb-2 text-2xl font-bold text-white">Daily Reports</h1>
        <p className="mb-6 text-white/60">
          Excel with sheets: Global, Senior, Junior, Dhol-Dhwaj, Tasha-Dhwaj, Dhwaj, Defaulters (&gt;5 consecutive absent days)
        </p>

        <div className="card space-y-4">
          <p className="text-sm text-white/50">
            Auto-generated daily at <strong>9:30 PM IST</strong> via Vercel Cron.
          </p>
          <button onClick={downloadReport} className="btn-primary w-full">
            Download Today&apos;s Report ({today})
          </button>
        </div>
      </main>
    </>
  );
}
