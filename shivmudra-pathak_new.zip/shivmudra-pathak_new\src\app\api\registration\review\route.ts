import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import {
  sendRegistrationApprovedEmail,
  sendRegistrationRejectedEmail,
} from "@/lib/email";

export async function PATCH(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: admin } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (admin?.role !== "admin") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const body = await request.json();
  const userId = body.user_id as string;
  const action = body.action as "approved" | "rejected";

  if (!userId || !["approved", "rejected"].includes(action)) {
    return NextResponse.json({ error: "user_id and action (approved|rejected) required" }, { status: 400 });
  }

  const adminClient = createAdminClient();

  const { data: member, error: fetchError } = await adminClient
    .from("profiles")
    .select("id, email, name, role, approval_status")
    .eq("id", userId)
    .single();

  if (fetchError || !member) {
    return NextResponse.json({ error: "Member not found" }, { status: 404 });
  }

  if (member.role !== "user") {
    return NextResponse.json({ error: "Only member registrations can be reviewed" }, { status: 400 });
  }

  if (member.approval_status !== "pending") {
    return NextResponse.json({ error: "Registration already reviewed" }, { status: 409 });
  }

  const updates =
    action === "approved"
      ? { approval_status: "approved" as const, status: "active" as const }
      : { approval_status: "rejected" as const, status: "inactive" as const };

  const { error: updateError } = await adminClient
    .from("profiles")
    .update(updates)
    .eq("id", userId);

  if (updateError) {
    return NextResponse.json({ error: updateError.message }, { status: 500 });
  }

  const emailResult =
    action === "approved"
      ? await sendRegistrationApprovedEmail(member.email, member.name)
      : await sendRegistrationRejectedEmail(member.email, member.name);

  return NextResponse.json({
    success: true,
    action,
    emailSent: emailResult.sent,
    emailNote: emailResult.error,
  });
}
