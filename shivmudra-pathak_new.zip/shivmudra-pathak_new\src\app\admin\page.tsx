import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { getISTDateString } from "@/lib/attendance-window";
import { fetchInstrumentDashboardData } from "@/lib/attendance-stats-server";
import { countAttendanceByCategory } from "@/lib/member-fields";
import { InstrumentAttendanceDashboard } from "@/components/InstrumentAttendanceDashboard";
import Link from "next/link";

export default async function AdminDashboard() {
  const profile = await requireRole(["admin"]);
  const supabase = await createClient();
  const today = getISTDateString();

  const [
    { todayStats, dailyHistory, memberList, presentIds },
    { count: pendingRequests },
    { count: pendingRegistrations },
  ] = await Promise.all([
    fetchInstrumentDashboardData(supabase, today),
    supabase.from("removal_requests").select("*", { count: "exact", head: true }).eq("status", "pending"),
    supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("role", "user")
      .eq("approval_status", "pending"),
  ]);

  const stats = countAttendanceByCategory(memberList, presentIds);

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-6xl p-6">
        <h1 className="mb-2 text-2xl font-bold text-white">Admin Dashboard</h1>
        <p className="mb-8 text-white/60">Welcome, {profile.name || profile.email}</p>

        <h2 className="mb-3 text-sm font-medium uppercase tracking-wide text-white/40">
          Overall
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="card">
            <p className="text-sm text-white/50">Active Members</p>
            <p className="text-3xl font-bold text-brand-500">{stats.total}</p>
          </div>
          <div className="card">
            <p className="text-sm text-white/50">Present Today</p>
            <p className="text-3xl font-bold text-green-400">{stats.totalPresent}</p>
          </div>
          <div className="card">
            <p className="text-sm text-white/50">Pending Registrations</p>
            <p className="text-3xl font-bold text-orange-400">{pendingRegistrations ?? 0}</p>
          </div>
          <div className="card">
            <p className="text-sm text-white/50">Pending Removal Requests</p>
            <p className="text-3xl font-bold text-yellow-400">{pendingRequests ?? 0}</p>
          </div>
        </div>

        <h2 className="mb-3 mt-8 text-sm font-medium uppercase tracking-wide text-white/40">
          Senior / Junior Breakdown
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="card border-l-4 border-l-blue-500">
            <p className="text-sm text-white/50">Senior Members</p>
            <p className="text-3xl font-bold text-blue-400">{stats.seniorTotal}</p>
          </div>
          <div className="card border-l-4 border-l-blue-500/50">
            <p className="text-sm text-white/50">Senior Present Today</p>
            <p className="text-3xl font-bold text-green-400">{stats.seniorPresent}</p>
            <p className="mt-1 text-xs text-white/40">
              {stats.seniorTotal > 0
                ? `${Math.round((stats.seniorPresent / stats.seniorTotal) * 100)}% attendance`
                : "—"}
            </p>
          </div>
          <div className="card border-l-4 border-l-purple-500">
            <p className="text-sm text-white/50">Junior Members</p>
            <p className="text-3xl font-bold text-purple-400">{stats.juniorTotal}</p>
          </div>
          <div className="card border-l-4 border-l-purple-500/50">
            <p className="text-sm text-white/50">Junior Present Today</p>
            <p className="text-3xl font-bold text-green-400">{stats.juniorPresent}</p>
            <p className="mt-1 text-xs text-white/40">
              {stats.juniorTotal > 0
                ? `${Math.round((stats.juniorPresent / stats.juniorTotal) * 100)}% attendance`
                : "—"}
            </p>
          </div>
        </div>

        <div className="mt-10">
          <InstrumentAttendanceDashboard
            today={today}
            todayStats={todayStats}
            dailyHistory={dailyHistory}
          />
        </div>

        <h2 className="mb-3 mt-10 text-sm font-medium uppercase tracking-wide text-white/40">
          Senior / Junior Dashboards
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="card border-l-4 border-l-blue-500 space-y-4">
            <div>
              <h3 className="font-semibold text-blue-400">Senior Dashboard</h3>
              <p className="text-sm text-white/50">
                {stats.seniorPresent}/{stats.seniorTotal} present today
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link href="/admin/senior" className="btn-secondary text-sm py-2 px-3">
                Open Senior
              </Link>
              <Link href="/admin/members/new/senior" className="btn-primary text-sm py-2 px-3">
                + Add Senior Member
              </Link>
            </div>
          </div>
          <div className="card border-l-4 border-l-purple-500 space-y-4">
            <div>
              <h3 className="font-semibold text-purple-400">Junior Dashboard</h3>
              <p className="text-sm text-white/50">
                {stats.juniorPresent}/{stats.juniorTotal} present today
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link href="/admin/junior" className="btn-secondary text-sm py-2 px-3">
                Open Junior
              </Link>
              <Link href="/admin/members/new/junior" className="btn-primary text-sm py-2 px-3">
                + Add Junior Member
              </Link>
            </div>
          </div>
        </div>

        <h2 className="mb-3 mt-10 text-sm font-medium uppercase tracking-wide text-white/40">
          Add Members
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Link
            href="/admin/members/new/senior"
            className="card border-l-4 border-l-blue-500 transition hover:border-blue-400/60"
          >
            <h3 className="font-semibold text-blue-400">+ Register Senior Member</h3>
            <p className="text-sm text-white/50">Add ज्येष्ठ vadak with photo & details</p>
          </Link>
          <Link
            href="/admin/members/new/junior"
            className="card border-l-4 border-l-purple-500 transition hover:border-purple-400/60"
          >
            <h3 className="font-semibold text-purple-400">+ Register Junior Member</h3>
            <p className="text-sm text-white/50">Add कनिष्ठ vadak with photo & details</p>
          </Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Link href="/admin/registrations" className="card hover:border-brand-500/50 transition">
            <h3 className="font-semibold text-white">Review Registrations</h3>
            <p className="text-sm text-white/50">
              {pendingRegistrations ?? 0} pending — approve before attendance
            </p>
          </Link>
          <Link href="/admin/geo-fence" className="card hover:border-brand-500/50 transition">
            <h3 className="font-semibold text-white">Set Geo-Fence</h3>
            <p className="text-sm text-white/50">Practice ground — 150m radius</p>
          </Link>
          <Link href="/admin/reports" className="card hover:border-brand-500/50 transition">
            <h3 className="font-semibold text-white">Daily Excel Report</h3>
            <p className="text-sm text-white/50">Summary + Senior/Junior sheets</p>
          </Link>
        </div>
      </main>
    </>
  );
}
