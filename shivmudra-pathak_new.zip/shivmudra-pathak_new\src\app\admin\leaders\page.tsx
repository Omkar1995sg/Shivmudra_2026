"use client";

import { AppNav } from "@/components/AppNav";
import { instrumentLabel } from "@/lib/member-fields";
import { useEffect, useState } from "react";

interface Member {
  id: string;
  name: string;
  email: string;
  instrument: string;
  role: string;
}

export default function LeadersPage() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/members/list")
      .then(async (r) => {
        const data = await r.json();
        setMembers(Array.isArray(data) ? data : []);
      })
      .catch(() => setMembers([]));
  }, []);

  async function promote(userId: string) {
    setLoading(userId);
    await fetch("/api/leaders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId }),
    });
    setMembers((m) => m.map((x) => (x.id === userId ? { ...x, role: "leader" } : x)));
    setLoading(null);
  }

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-3xl p-6">
        <h1 className="mb-6 text-2xl font-bold text-white">Manage Leaders</h1>
        <p className="mb-4 text-sm text-white/60">
          Promote active members to Leader role. Leaders can view attendance and raise removal requests.
        </p>
        <div className="space-y-2">
          {members
            .filter((m) => m.role === "user" || m.role === "leader")
            .map((m) => (
              <div key={m.id} className="card flex items-center justify-between py-4">
                <div>
                  <p className="font-medium text-white">{m.name}</p>
                  <p className="text-sm text-white/50 capitalize">
                    {instrumentLabel(m.instrument)} • {m.role}
                  </p>
                </div>
                {m.role === "user" && (
                  <button
                    onClick={() => promote(m.id)}
                    className="btn-primary text-sm py-2"
                    disabled={loading === m.id}
                  >
                    Make Leader
                  </button>
                )}
                {m.role === "leader" && (
                  <span className="text-sm text-brand-500">Leader</span>
                )}
              </div>
            ))}
        </div>
      </main>
    </>
  );
}
