/**
 * End-to-end registration + photo test. Run:
 *   node scripts/test_registration_photo.mjs
 */
import { readFileSync, existsSync, writeFileSync, unlinkSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const envPath = join(root, ".env.local");
const pngPath = join(root, "scripts", "_test_pixel.png");

function loadEnv() {
  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^([^#=]+)=(.*)$/);
    if (m) process.env[m[1].trim()] = m[2].trim();
  }
}

loadEnv();

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64"
);
writeFileSync(pngPath, png);

const email = `photo-test-${Date.now()}@example.com`;
const form = new FormData();
form.append("email", email);
form.append("password", "testpass123");
form.append("name", "Photo Test User");
form.append("phone", "9876543210");
form.append("instrument", "dhol");
form.append("previous_pathak", "false");
form.append("photo", new Blob([png], { type: "image/png" }), "test.png");

const res = await fetch("http://localhost:3000/api/registration", {
  method: "POST",
  body: form,
});

const data = await res.json();
console.log("Status:", res.status);
console.log("Response:", JSON.stringify(data, null, 2));

unlinkSync(pngPath);

if (!res.ok) process.exit(1);
if (!data.photoUploaded) {
  console.error("photo_url was NOT saved — check photoNote above");
  process.exit(1);
}
console.log("Registration with photo OK for", email);
