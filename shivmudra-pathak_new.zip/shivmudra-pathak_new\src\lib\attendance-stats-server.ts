import type { SupabaseClient } from "@supabase/supabase-js";
import {
  ATTENDANCE_DASHBOARD_START,
  buildDailyInstrumentAttendance,
  buildInstrumentTodayStats,
} from "@/lib/attendance-stats";

export async function fetchInstrumentDashboardData(
  supabase: SupabaseClient,
  today: string
) {
  const [{ data: members }, { data: todayAttendance }, { data: historyAttendance }] =
    await Promise.all([
      supabase
        .from("profiles")
        .select("id, instrument, member_category")
        .eq("role", "user")
        .eq("status", "active")
        .eq("approval_status", "approved"),
      supabase.from("attendance").select("user_id").eq("attendance_date", today),
      supabase
        .from("attendance")
        .select("user_id, attendance_date")
        .gte("attendance_date", ATTENDANCE_DASHBOARD_START)
        .lte("attendance_date", today),
    ]);

  const memberList = members ?? [];
  const presentIds = new Set(todayAttendance?.map((a) => a.user_id) ?? []);

  const todayStats = buildInstrumentTodayStats(memberList, presentIds);

  const dailyHistory =
    today >= ATTENDANCE_DASHBOARD_START
      ? buildDailyInstrumentAttendance(
          memberList,
          historyAttendance ?? [],
          ATTENDANCE_DASHBOARD_START,
          today
        )
      : [];

  return { todayStats, dailyHistory, memberList, presentIds };
}
