import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { getISTDateString } from "@/lib/attendance-window";
import { instrumentLabel } from "@/lib/member-fields";
import Link from "next/link";

export default async function LeaderDashboard() {
  await requireRole(["leader", "admin"]);
  const supabase = await createClient();
  const today = getISTDateString();

  const { data: members } = await supabase
    .from("profiles")
    .select("id, name, phone, instrument, status")
    .eq("role", "user")
    .eq("status", "active")
    .eq("approval_status", "approved")
    .order("instrument")
    .order("name");

  const { data: attendance } = await supabase
    .from("attendance")
    .select("user_id, marked_at, geo_verified, distance_meters")
    .eq("attendance_date", today);

  const attMap = new Map(attendance?.map((a) => [a.user_id, a]) ?? []);

  return (
    <>
      <AppNav role="leader" />
      <main className="mx-auto max-w-4xl p-6">
        <h1 className="mb-2 text-2xl font-bold text-white">Today&apos;s Attendance</h1>
        <p className="mb-6 text-white/60">{today}</p>

        <div className="overflow-x-auto rounded-xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/5 text-white/70">
              <tr>
                <th className="p-3">Name</th>
                <th className="p-3">Instrument</th>
                <th className="p-3">Status</th>
                <th className="p-3">Time</th>
                <th className="p-3">Geo</th>
                <th className="p-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {members?.map((m) => {
                const att = attMap.get(m.id);
                return (
                  <tr key={m.id} className="border-t border-white/10">
                    <td className="p-3 text-white">{m.name}</td>
                    <td className="p-3 text-white/70">{instrumentLabel(m.instrument)}</td>
                    <td className="p-3">
                      <span
                        className={
                          att ? "text-green-400" : "text-red-400"
                        }
                      >
                        {att ? "Present" : "Absent"}
                      </span>
                    </td>
                    <td className="p-3 text-white/50">
                      {att?.marked_at
                        ? new Date(att.marked_at).toLocaleTimeString("en-IN", {
                            timeZone: "Asia/Kolkata",
                          })
                        : "—"}
                    </td>
                    <td className="p-3 text-white/50">
                      {att?.geo_verified ? `✓ ${att.distance_meters}m` : "—"}
                    </td>
                    <td className="p-3">
                      {!att && (
                        <Link
                          href={`/leader/requests?user=${m.id}&name=${encodeURIComponent(m.name)}`}
                          className="text-xs text-brand-500 hover:underline"
                        >
                          Request removal
                        </Link>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
}
