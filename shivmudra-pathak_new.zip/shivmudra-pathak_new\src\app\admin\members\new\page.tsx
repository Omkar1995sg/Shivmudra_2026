import { AppNav } from "@/components/AppNav";
import { requireRole } from "@/lib/auth";
import Link from "next/link";

export default async function RegisterMemberChooserPage() {
  await requireRole(["admin"]);

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-3xl p-6">
        <Link href="/admin" className="mb-4 inline-block text-sm text-white/50 hover:text-white">
          ← Dashboard
        </Link>
        <h1 className="mb-2 text-2xl font-bold text-white">Register New Member</h1>
        <p className="mb-8 text-white/60">Choose Senior or Junior — forms are separate.</p>

        <div className="grid gap-4 sm:grid-cols-2">
          <Link
            href="/admin/members/new/senior"
            className="card border-l-4 border-l-blue-500 transition hover:border-blue-400/60"
          >
            <h2 className="text-lg font-semibold text-blue-400">+ Add Senior Member</h2>
            <p className="mt-2 text-sm text-white/50">
              ज्येष्ठ सदस्य — senior pathak registration form
            </p>
          </Link>
          <Link
            href="/admin/members/new/junior"
            className="card border-l-4 border-l-purple-500 transition hover:border-purple-400/60"
          >
            <h2 className="text-lg font-semibold text-purple-400">+ Add Junior Member</h2>
            <p className="mt-2 text-sm text-white/50">
              कनिष्ठ सदस्य — junior pathak registration form
            </p>
          </Link>
        </div>
      </main>
    </>
  );
}
