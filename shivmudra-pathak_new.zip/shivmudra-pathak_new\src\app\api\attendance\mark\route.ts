import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { isWithinAttendanceWindow, getISTDateString } from "@/lib/attendance-window";
import { isWithinFence } from "@/lib/geo";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role, status, approval_status")
    .eq("id", user.id)
    .single();

  if (!profile || profile.status !== "active" || profile.approval_status !== "approved") {
    if (profile?.approval_status === "pending") {
      return NextResponse.json(
        { error: "Registration pending admin approval. Attendance is not available yet." },
        { status: 403 }
      );
    }
    if (profile?.approval_status === "rejected") {
      return NextResponse.json(
        { error: "Your registration was not approved. Contact pathak management." },
        { status: 403 }
      );
    }
    return NextResponse.json({ error: "Account inactive" }, { status: 403 });
  }

  if (!isWithinAttendanceWindow()) {
    return NextResponse.json(
      { error: "Attendance only allowed 8:30 PM – 9:30 PM IST" },
      { status: 403 }
    );
  }

  const body = await request.json();
  const { latitude, longitude } = body;

  if (typeof latitude !== "number" || typeof longitude !== "number") {
    return NextResponse.json({ error: "Location required" }, { status: 400 });
  }

  const { data: ground } = await supabase
    .from("practice_ground")
    .select("*")
    .limit(1)
    .single();

  if (!ground) {
    return NextResponse.json({ error: "Practice ground not configured" }, { status: 500 });
  }

  const { inside, distance } = isWithinFence(
    latitude,
    longitude,
    ground.center_lat,
    ground.center_lng,
    ground.radius_meters
  );

  if (!inside) {
    return NextResponse.json(
      {
        error: `You are ${distance}m away. Must be within ${ground.radius_meters}m of sarav ground.`,
        distance,
      },
      { status: 403 }
    );
  }

  const today = getISTDateString();

  const { data: existing } = await supabase
    .from("attendance")
    .select("id")
    .eq("user_id", user.id)
    .eq("attendance_date", today)
    .maybeSingle();

  if (existing) {
    return NextResponse.json({ error: "Already marked today", alreadyMarked: true }, { status: 409 });
  }

  const { error } = await supabase.from("attendance").insert({
    user_id: user.id,
    attendance_date: today,
    latitude,
    longitude,
    distance_meters: distance,
    geo_verified: true,
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true, distance, message: "उपस्थिती नोंदवली!" });
}
