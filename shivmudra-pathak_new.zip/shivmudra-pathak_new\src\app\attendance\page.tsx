import Link from "next/link";
import { BrandingHeader } from "@/components/BrandingHeader";

export default function AttendanceHubPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-lg flex-col justify-center p-6">
      <BrandingHeader compact />
      <p className="mt-6 text-center text-sm text-white/60">Select your attendance portal</p>
      <div className="mt-6 grid gap-3">
        <Link href="/attendance/senior" className="btn-primary text-center">
          Senior Attendance → /attendance/senior
        </Link>
        <Link href="/attendance/junior" className="btn-primary text-center">
          Junior Attendance → /attendance/junior
        </Link>
      </div>
    </main>
  );
}
