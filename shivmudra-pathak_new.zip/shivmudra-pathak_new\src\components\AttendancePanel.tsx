"use client";

import { createClient } from "@/lib/supabase/client";
import {
  getWindowMessage,
  isWithinAttendanceWindow,
  getMinutesUntilWindowOpens,
  getMinutesUntilWindowCloses,
} from "@/lib/attendance-window";
import { categoryLabel, type MemberCategory } from "@/lib/member-fields";
import type { ApprovalStatus } from "@/types/database";
import { BrandingHeader } from "@/components/BrandingHeader";
import Link from "next/link";
import { useEffect, useState, useCallback } from "react";

interface AttendancePanelProps {
  portalCategory: MemberCategory;
}

export function AttendancePanel({ portalCategory }: AttendancePanelProps) {
  const [windowOpen, setWindowOpen] = useState(false);
  const [minsLeft, setMinsLeft] = useState<number | null>(null);
  const [minsUntilOpen, setMinsUntilOpen] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);
  const [alreadyMarked, setAlreadyMarked] = useState(false);
  const [userName, setUserName] = useState("");
  const [memberCategory, setMemberCategory] = useState<string | null>(null);
  const [approvalStatus, setApprovalStatus] = useState<ApprovalStatus | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [isSignedIn, setIsSignedIn] = useState(false);

  const tick = useCallback(() => {
    setWindowOpen(isWithinAttendanceWindow());
    setMinsLeft(getMinutesUntilWindowCloses());
    setMinsUntilOpen(getMinutesUntilWindowOpens());
  }, []);

  useEffect(() => {
    tick();
    const interval = setInterval(tick, 30000);
    return () => clearInterval(interval);
  }, [tick]);

  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getUser().then(({ data: { user } }) => {
      setAuthChecked(true);
      if (!user) {
        setIsSignedIn(false);
        return;
      }
      setIsSignedIn(true);
      supabase
        .from("profiles")
        .select("name, approval_status, member_category")
        .eq("id", user.id)
        .single()
        .then(({ data }) => {
          if (data) {
            setUserName(data.name);
            setApprovalStatus(data.approval_status as ApprovalStatus);
            setMemberCategory(data.member_category);
          }
        });
    });
  }, []);

  const categoryMismatch =
    memberCategory && memberCategory !== portalCategory;
  const canMarkAttendance = approvalStatus === "approved" && !categoryMismatch;

  async function markPresent() {
    if (!canMarkAttendance) return;

    setLoading(true);
    setMessage("");

    if (!navigator.geolocation) {
      setMessage("GPS not supported on this device.");
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const res = await fetch("/api/attendance/mark", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          }),
        });
        const data = await res.json();

        if (res.ok) {
          setSuccess(true);
          setMessage(data.message ?? "उपस्थिती नोंदवली!");
          setAlreadyMarked(true);
        } else {
          if (data.alreadyMarked) setAlreadyMarked(true);
          setMessage(data.error ?? "Failed");
        }
        setLoading(false);
      },
      () => {
        setMessage("Location permission denied. Enable GPS to mark attendance.");
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 15000 }
    );
  }

  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    window.location.href = `/login/${portalCategory}`;
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center p-6">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-15"
        style={{ backgroundImage: "url(/branding/group-photo.jpg)" }}
      />
      <div className="card relative w-full max-w-md text-center">
        <BrandingHeader compact />
        <p className="mt-3 text-sm font-medium text-brand-400">
          {categoryLabel(portalCategory)} Attendance Portal
        </p>
        {userName && (
          <p className="mt-2 text-lg font-semibold text-white">नमस्कार, {userName}</p>
        )}

        {authChecked && !isSignedIn && (
          <div className="mt-6 space-y-3">
            <p className="text-sm text-white/60">Sign in to mark {categoryLabel(portalCategory).toLowerCase()} attendance</p>
            <Link href={`/login/${portalCategory}`} className="btn-primary inline-block w-full">
              {categoryLabel(portalCategory)} Sign In
            </Link>
          </div>
        )}

        {isSignedIn && categoryMismatch && (
          <div className="mt-6 rounded-xl border border-orange-500/30 bg-orange-500/10 px-4 py-3">
            <p className="text-sm font-medium text-orange-300">Wrong attendance portal</p>
            <p className="mt-1 text-xs text-white/60">
              You are registered as {categoryLabel(memberCategory)}. Please use the{" "}
              {categoryLabel(memberCategory)} attendance link.
            </p>
            <Link
              href={`/user/${memberCategory}`}
              className="btn-primary mt-3 inline-block w-full text-sm py-2"
            >
              Go to {categoryLabel(memberCategory)} Attendance
            </Link>
          </div>
        )}

        {isSignedIn && approvalStatus === "pending" && !categoryMismatch && (
          <div className="mt-6 rounded-xl border border-yellow-500/30 bg-yellow-500/10 px-4 py-3">
            <p className="text-sm font-medium text-yellow-300">Registration Pending Approval</p>
            <p className="mt-1 text-xs text-white/60">
              Admin will review your application. Attendance will be enabled after approval.
            </p>
          </div>
        )}

        {isSignedIn && approvalStatus === "rejected" && !categoryMismatch && (
          <div className="mt-6 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3">
            <p className="text-sm font-medium text-red-300">Registration Not Approved</p>
            <p className="mt-1 text-xs text-white/60">
              Please contact pathak management for more information.
            </p>
          </div>
        )}

        {isSignedIn && canMarkAttendance && (
          <>
            <p className="mt-4 text-sm text-white/60">{getWindowMessage()}</p>

            {windowOpen && minsLeft !== null && (
              <p className="mt-2 text-sm text-green-400">
                Window open — {minsLeft} min remaining
              </p>
            )}
            {!windowOpen && minsUntilOpen !== null && (
              <p className="mt-2 text-sm text-yellow-400">Opens in {minsUntilOpen} minutes</p>
            )}
            {!windowOpen && minsUntilOpen === null && (
              <p className="mt-2 text-sm text-red-400">Window closed for today</p>
            )}

            <button
              onClick={markPresent}
              disabled={!windowOpen || loading || success || alreadyMarked}
              className="btn-primary mt-8 w-full py-5 text-lg"
            >
              {loading
                ? "Getting location..."
                : success || alreadyMarked
                  ? "✓ उपस्थिती नोंदवली"
                  : "उपस्थिती नोंदवा | Mark Present"}
            </button>

            <p className="mt-4 text-xs text-white/40">
              Must be at sarav ground (150m) with GPS enabled
            </p>
          </>
        )}

        {message && (
          <p className={`mt-4 text-sm ${success ? "text-green-400" : "text-red-300"}`}>
            {message}
          </p>
        )}

        {isSignedIn && (
          <button onClick={signOut} className="mt-8 text-sm text-white/40 hover:text-white">
            Sign Out
          </button>
        )}
      </div>
    </main>
  );
}
