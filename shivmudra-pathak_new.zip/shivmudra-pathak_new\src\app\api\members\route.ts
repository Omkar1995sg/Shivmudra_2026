import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { uploadMemberPhoto } from "@/lib/member-photo";
import {
  isValidBloodGroup,
  isValidMemberCategory,
} from "@/lib/member-fields";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: admin } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (admin?.role !== "admin") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const formData = await request.formData();
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;
  const name = formData.get("name") as string;
  const address = formData.get("address") as string;
  const phone = formData.get("phone") as string;
  const instrument = formData.get("instrument") as string;
  const reference = formData.get("reference") as string;
  const previous_pathak = formData.get("previous_pathak") === "true";
  const previous_pathak_name = (formData.get("previous_pathak_name") as string) || null;
  const blood_group = (formData.get("blood_group") as string)?.trim();
  const member_category = (formData.get("member_category") as string)?.trim();
  const photoRaw = formData.get("photo");
  const photo = photoRaw instanceof File ? photoRaw : null;

  if (!email || !password || !name || !phone || !instrument || !blood_group || !member_category) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  if (!isValidBloodGroup(blood_group)) {
    return NextResponse.json({ error: "Invalid blood group" }, { status: 400 });
  }

  if (!isValidMemberCategory(member_category)) {
    return NextResponse.json({ error: "Invalid member category" }, { status: 400 });
  }
  const adminClient = createAdminClient();

  const { data: authData, error: authError } = await adminClient.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { name },
  });

  if (authError || !authData.user) {
    return NextResponse.json({ error: authError?.message ?? "Failed to create user" }, { status: 500 });
  }

  const { photo_url, error: photoError } = await uploadMemberPhoto(
    adminClient,
    authData.user.id,
    photo
  );

  if (photoError) {
    console.error("Admin member photo upload failed:", photoError);
  }
  const { error: profileError } = await adminClient
    .from("profiles")
    .update({
      name,
      address: address ?? "",
      phone,
      instrument,
      reference: reference ?? "",
      previous_pathak,
      previous_pathak_name,
      photo_url,
      blood_group,
      member_category,
      role: "user",      status: "active",
      approval_status: "approved",
    })
    .eq("id", authData.user.id);

  if (profileError) {
    return NextResponse.json({ error: profileError.message }, { status: 500 });
  }

  return NextResponse.json({
    success: true,
    userId: authData.user.id,
    photoUploaded: Boolean(photo_url),
    photoNote: photoError ?? undefined,
  });}
