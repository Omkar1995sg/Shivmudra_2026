-- Member photo storage bucket (run in Supabase SQL Editor if photo_url is NULL after registration)

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'member-photos',
  'member-photos',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']::text[]
)
ON CONFLICT (id) DO UPDATE
SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Public read member photos" ON storage.objects;
CREATE POLICY "Public read member photos"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'member-photos');

DROP POLICY IF EXISTS "Service role upload member photos" ON storage.objects;
CREATE POLICY "Service role upload member photos"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'member-photos');

DROP POLICY IF EXISTS "Service role update member photos" ON storage.objects;
CREATE POLICY "Service role update member photos"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'member-photos');
