import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const authHeader = request.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const base = process.env.VERCEL_URL
    ? `https://${process.env.VERCEL_URL}`
    : process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  const res = await fetch(`${base}/api/reports/generate`, {
    headers: { authorization: `Bearer ${process.env.CRON_SECRET}` },
  });

  if (!res.ok) {
    return NextResponse.json({ error: "Report generation failed" }, { status: 500 });
  }

  return NextResponse.json({ success: true, date: new Date().toISOString() });
}
