"""Inspect auth identities and Google OAuth readiness for bootstrap admin."""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EMAIL = "omkargavkhadkar@gmail.com"


def load_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def req(url: str, headers: dict[str, str], method="GET", body=None):
    data = None if body is None else json.dumps(body).encode()
    h = dict(headers)
    if body is not None:
        h["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(request, timeout=30) as resp:
            raw = resp.read().decode()
            return resp.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else None
        except json.JSONDecodeError:
            payload = {"raw": raw[:400]}
        return e.code, payload
    except Exception as e:  # noqa: BLE001
        return 0, {"error": str(e)}


def main():
    env = load_env(ROOT / ".env.local")
    url = env["NEXT_PUBLIC_SUPABASE_URL"].rstrip("/")
    service = env["SUPABASE_SERVICE_ROLE_KEY"]
    anon = env["NEXT_PUBLIC_SUPABASE_ANON_KEY"]
    headers = {"apikey": service, "Authorization": f"Bearer {service}"}

    st, payload = req(f"{url}/auth/v1/admin/users?page=1&per_page=200", headers)
    users = (payload or {}).get("users") or []
    user = next((u for u in users if (u.get("email") or "").lower() == EMAIL), None)
    if not user:
        print("user missing")
        return
    uid = user["id"]
    st, detail = req(f"{url}/auth/v1/admin/users/{uid}", headers)
    print(f"user_detail_status={st}")
    if isinstance(detail, dict):
        print("email:", detail.get("email"))
        print("providers:", (detail.get("app_metadata") or {}).get("providers"))
        print("encrypted_password_set:", bool(detail.get("encrypted_password")))
        print("identities_count:", len(detail.get("identities") or []))
        for i in detail.get("identities") or []:
            print(
                "identity:",
                {
                    "provider": i.get("provider"),
                    "email": (i.get("identity_data") or {}).get("email"),
                    "last_sign_in_at": i.get("last_sign_in_at"),
                },
            )

    # Google OAuth authorize probe (should redirect or return provider config error)
    oauth = (
        f"{url}/auth/v1/authorize?provider=google"
        f"&redirect_to=http%3A%2F%2Flocalhost%3A3000%2Fauth%2Fcallback"
    )
    st, body = req(oauth, {"apikey": anon, "Authorization": f"Bearer {anon}"})
    print(f"google_oauth_probe_status={st}")
    if isinstance(body, dict):
        print(
            "google_oauth_body:",
            {
                "error": body.get("error"),
                "error_description": body.get("error_description"),
                "msg": body.get("msg"),
                "message": body.get("message"),
            },
        )

    # Profile approval fields
    st, profiles = req(
        f"{url}/rest/v1/profiles?select=*&email=eq.{EMAIL}",
        headers,
    )
    print(f"profile_status={st}")
    if isinstance(profiles, list) and profiles:
        p = profiles[0]
        keys = [
            "role",
            "status",
            "approval_status",
            "registration_status",
            "member_category",
            "name",
            "full_name",
        ]
        print("profile_fields:", {k: p.get(k) for k in keys if k in p or True})


if __name__ == "__main__":
    main()
