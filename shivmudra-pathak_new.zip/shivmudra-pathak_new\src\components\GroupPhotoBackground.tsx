interface GroupPhotoBackgroundProps {
  /** 10 = subtle (login), 15 = stronger (attendance/register) */
  strength?: "subtle" | "medium";
}

export function GroupPhotoBackground({ strength = "medium" }: GroupPhotoBackgroundProps) {
  const opacity = strength === "subtle" ? "opacity-10" : "opacity-15";

  return (
    <div
      className={`pointer-events-none absolute inset-0 bg-cover bg-top ${opacity}`}
      style={{ backgroundImage: "url(/branding/group-photo.jpg?v=2)" }}
      aria-hidden
    />
  );
}
