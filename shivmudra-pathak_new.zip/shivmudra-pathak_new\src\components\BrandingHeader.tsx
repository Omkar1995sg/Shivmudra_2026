import { LogoEmblem } from "@/components/LogoEmblem";



interface BrandingHeaderProps {

  showGroupPhoto?: boolean;

  subtitle?: string;

  compact?: boolean;

}



export function BrandingHeader({

  showGroupPhoto = false,

  subtitle,

  compact = false,

}: BrandingHeaderProps) {

  return (

    <div className="text-center">

      <LogoEmblem compact={compact} />

      <p className="mt-3 text-sm font-medium tracking-wide text-brand-500">

        ।। मुद्रा भद्राय राजते ।।

      </p>

      {subtitle && (

        <p className="mt-1 text-sm text-white/60">{subtitle}</p>

      )}

      {showGroupPhoto && (

        <div className="relative mx-auto mt-4 max-w-xl overflow-hidden rounded-2xl border border-white/10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/branding/group-photo.jpg?v=2"
            alt="Shivmudra Pathak"
            className="aspect-[783/672] w-full object-cover object-top opacity-90"
            draggable={false}
          />
        </div>

      )}

    </div>

  );

}


