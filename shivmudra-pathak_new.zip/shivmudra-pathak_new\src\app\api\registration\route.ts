import { NextResponse } from "next/server";
import { createAdminClient, getSupabaseConfigError } from "@/lib/supabase/admin";
import { uploadMemberPhoto } from "@/lib/member-photo";
import { isGmailEmail } from "@/lib/auth-redirect";
import {
  isValidBloodGroup,
  isValidMemberCategory,
} from "@/lib/member-fields";

function friendlyFetchError(err: unknown): string {
  if (!err) return "Registration failed";

  const anyErr = err as {
    message?: string;
    code?: string;
    cause?: { code?: string; hostname?: string; message?: string };
  };

  const message = anyErr.message?.trim() || (err instanceof Error ? err.message : "");
  const cause = anyErr.cause;
  const causeMsg = `${cause?.code ?? ""} ${cause?.message ?? ""} ${message}`.toLowerCase();

  if (causeMsg.includes("self_signed_cert") || causeMsg.includes("self-signed certificate")) {
    return "Corporate SSL interception blocked Supabase. Restart with npm run dev:corp (local only).";
  }

  if (cause?.code === "ENOTFOUND" || message.toLowerCase().includes("fetch failed")) {
    const host = cause?.hostname ? ` (${cause.hostname})` : "";
    return `Cannot reach Supabase${host}. Check NEXT_PUBLIC_SUPABASE_URL in .env.local and restart the dev server.`;
  }

  if (message) return message;

  try {
    const dumped = JSON.stringify(err);
    if (dumped && dumped !== "{}") return dumped;
  } catch {
    /* ignore */
  }

  return "Registration failed";
}

/** Public self-registration — creates account pending admin approval. */
export async function POST(request: Request) {
  try {
    const configError = getSupabaseConfigError();
    if (configError) {
      return NextResponse.json({ error: configError }, { status: 500 });
    }

    const formData = await request.formData();
    const email = (formData.get("email") as string)?.trim().toLowerCase();
    const password = formData.get("password") as string;
    const name = (formData.get("name") as string)?.trim();
    const address = (formData.get("address") as string)?.trim() ?? "";
    const phone = (formData.get("phone") as string)?.trim();
    const instrument = formData.get("instrument") as string;
    const reference = (formData.get("reference") as string)?.trim() ?? "";
    const previous_pathak = formData.get("previous_pathak") === "true";
    const previous_pathak_name = (formData.get("previous_pathak_name") as string)?.trim() || null;
    const blood_group = (formData.get("blood_group") as string)?.trim();
    const member_category = (formData.get("member_category") as string)?.trim();
    const photoRaw = formData.get("photo");
    const photo = photoRaw instanceof File ? photoRaw : null;

    if (!email || !password || !name || !phone || !instrument || !blood_group || !member_category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    if (!isValidBloodGroup(blood_group)) {
      return NextResponse.json({ error: "Invalid blood group" }, { status: 400 });
    }

    if (!isValidMemberCategory(member_category)) {
      return NextResponse.json({ error: "Invalid registration type (senior/junior)" }, { status: 400 });
    }

    if (!isGmailEmail(email)) {
      return NextResponse.json({ error: "Please use a Gmail address (@gmail.com)." }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "Password must be at least 6 characters" }, { status: 400 });
    }

    const adminClient = createAdminClient();

    const { data: authData, error: authError } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name },
    });

    if (authError || !authData.user) {
      let msg = friendlyFetchError(authError) || "Failed to create account";
      if (msg === "{}" || msg.toLowerCase().includes("database error creating new user")) {
        msg =
          "Database error creating user. Run supabase/migrations/001_registration_approval.sql in the Supabase SQL Editor, then try again.";
      }
      const status = msg.toLowerCase().includes("already") ? 409 : 500;
      return NextResponse.json({ error: msg }, { status });
    }

    const { photo_url, error: photoError } = await uploadMemberPhoto(
      adminClient,
      authData.user.id,
      photo
    );

    if (photoError) {
      console.error("Registration photo upload failed:", photoError);
    }

    const bootstrapEmail = (process.env.BOOTSTRAP_ADMIN_EMAIL ?? "omkargavkhadkar@gmail.com")
      .trim()
      .toLowerCase();
    const isBootstrapAdmin = email === bootstrapEmail;

    const { error: profileError } = await adminClient
      .from("profiles")
      .update({
        name,
        address,
        phone,
        instrument,
        reference,
        previous_pathak,
        previous_pathak_name,
        photo_url,
        blood_group,
        member_category,
        role: isBootstrapAdmin ? "admin" : "user",
        status: isBootstrapAdmin ? "active" : "inactive",
        approval_status: isBootstrapAdmin ? "approved" : "pending",
      })
      .eq("id", authData.user.id);

    if (profileError) {
      await adminClient.auth.admin.deleteUser(authData.user.id);
      return NextResponse.json({ error: profileError.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message:
        "Registration submitted. You can sign in after admin approval.",
      photoUploaded: Boolean(photo_url),
      photoNote: photoError
        ? `Registration saved but photo was not uploaded: ${photoError}`
        : undefined,
    });
  } catch (err) {
    return NextResponse.json({ error: friendlyFetchError(err) }, { status: 500 });
  }
}
