"""Phase 1 registration & approval tests (no Node required)."""
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(path: str) -> str:
    with open(os.path.join(ROOT, path), encoding="utf-8") as f:
        return f.read()


def test_phase1_files_exist():
    required = [
        "src/app/register/page.tsx",
        "src/app/admin/registrations/page.tsx",
        "src/app/api/registration/route.ts",
        "src/app/api/registration/list/route.ts",
        "src/app/api/registration/review/route.ts",
        "src/lib/email.ts",
        "supabase/migrations/001_registration_approval.sql",
    ]
    for f in required:
        assert os.path.isfile(os.path.join(ROOT, f)), f"Missing: {f}"
    print(f"PASS phase1 files: {len(required)} present")


def test_schema_has_approval_status():
    sql = read("supabase/schema.sql")
    assert "approval_status" in sql
    assert "CREATE TYPE approval_status" in sql
    print("PASS schema defines approval_status")


def test_self_register_page_copy():
    page = read("src/app/register/page.tsx")
    assert "Member Registration" in page
    assert 'name="email"' in page
    assert "Submit Registration" in page
    print("PASS /register page content")


def test_login_links_to_register():
    page = read("src/app/login/page.tsx")
    assert 'href="/register"' in page
    assert "Register here" in page
    assert "isSignUp" not in page
    print("PASS /login links to self-registration")


def test_registration_api_creates_pending():
    route = read("src/app/api/registration/route.ts")
    assert 'approval_status: "pending"' in route
    assert 'status: "inactive"' in route
    print("PASS registration API sets pending + inactive")


def test_review_api_approves_and_emails():
    route = read("src/app/api/registration/review/route.ts")
    assert "sendRegistrationApprovedEmail" in route
    assert "sendRegistrationRejectedEmail" in route
    assert 'approval_status: "approved"' in route
    print("PASS review API approve/reject + email")


def test_attendance_blocks_unapproved():
    route = read("src/app/api/attendance/mark/route.ts")
    assert "approval_status" in route
    assert "pending admin approval" in route
    print("PASS attendance API blocks unapproved members")


def test_user_portal_shows_pending_state():
    page = read("src/app/user/page.tsx")
    assert "Registration Pending Approval" in page
    assert 'approvalStatus === "approved"' in page
    print("PASS user portal pending/approved UI")


def test_middleware_allows_public_register():
    mw = read("src/middleware.ts")
    assert 'path === "/register"' in mw
    assert 'path === "/api/registration"' in mw
    print("PASS middleware public routes")


def test_admin_nav_has_registrations():
    nav = read("src/components/AppNav.tsx")
    assert "/admin/registrations" in nav
    print("PASS admin nav registrations link")


if __name__ == "__main__":
    test_phase1_files_exist()
    test_schema_has_approval_status()
    test_self_register_page_copy()
    test_login_links_to_register()
    test_registration_api_creates_pending()
    test_review_api_approves_and_emails()
    test_attendance_blocks_unapproved()
    test_user_portal_shows_pending_state()
    test_middleware_allows_public_register()
    test_admin_nav_has_registrations()
    print("\nAll Phase 1 static tests passed.")
