"use client";

import { AppNav } from "@/components/AppNav";
import { GeoFenceEditor } from "@/components/GeoFenceEditor";
import { useEffect, useState } from "react";

export default function GeoFencePage() {
  const [ground, setGround] = useState({
    center_lat: 18.5204,
    center_lng: 73.8567,
    radius_meters: 150,
  });

  useEffect(() => {
    fetch("/api/geo-fence")
      .then(async (r) => {
        const data = await r.json().catch(() => null);
        if (r.ok && data?.center_lat) setGround(data);
      })
      .catch(() => {});
  }, []);

  async function handleSave(lat: number, lng: number, radius: number) {
    const res = await fetch("/api/geo-fence", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        center_lat: lat,
        center_lng: lng,
        radius_meters: radius,
        name: "Shivmudra Sarav Ground",
      }),
    });
    if (!res.ok) throw new Error("Save failed");
    setGround({ center_lat: lat, center_lng: lng, radius_meters: radius });
  }

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-3xl p-6">
        <h1 className="mb-2 text-2xl font-bold text-white">Practice Ground Geo-Fence</h1>
        <p className="mb-6 text-white/60">
          Click on the map to set sarav ground center. Users mark attendance within the orange circle.
        </p>
        <div className="card">
          <GeoFenceEditor
            initialLat={ground.center_lat}
            initialLng={ground.center_lng}
            initialRadius={ground.radius_meters}
            onSave={handleSave}
          />
        </div>
      </main>
    </>
  );
}
