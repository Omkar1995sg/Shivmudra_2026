/**
 * Quick storage upload diagnostic. Run from shivmudra-pathak:
 *   node scripts/test_photo_upload.mjs
 */
import { readFileSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { createClient } from "@supabase/supabase-js";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const envPath = join(root, ".env.local");

function loadEnv() {
  if (!existsSync(envPath)) {
    console.error("Missing .env.local");
    process.exit(1);
  }
  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^([^#=]+)=(.*)$/);
    if (m) process.env[m[1].trim()] = m[2].trim();
  }
}

loadEnv();

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
const bucket =
  process.env.SUPABASE_PHOTOS_BUCKET?.trim() || "Shivmudra_attendance_bucket_2026";

if (!url || !key) {
  console.error("Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local");
  process.exit(1);
}

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const supabase = createClient(url, key, {
  auth: { autoRefreshToken: false, persistSession: false },
});

const testId = `diag-${Date.now()}`;
const path = `${testId}/photo.png`;
const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64"
);

console.log("Bucket:", bucket);
console.log("Upload path:", path);

const { error } = await supabase.storage.from(bucket).upload(path, png, {
  contentType: "image/png",
  upsert: true,
});

if (error) {
  console.error("UPLOAD FAILED:", error.message);
  process.exit(1);
}

const { data } = supabase.storage.from(bucket).getPublicUrl(path);
console.log("UPLOAD OK");
console.log("Public URL:", data.publicUrl);

await supabase.storage.from(bucket).remove([path]);
console.log("Cleanup OK");
