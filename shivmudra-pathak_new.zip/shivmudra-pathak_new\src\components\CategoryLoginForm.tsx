"use client";

import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useState, useEffect } from "react";
import { BrandingHeader } from "@/components/BrandingHeader";
import { getPostLoginPath, loginErrorMessage } from "@/lib/auth-redirect";
import { categoryLabel, type MemberCategory } from "@/lib/member-fields";

const categoryStyles: Record<
  MemberCategory,
  { badge: string; border: string; title: string; subtitle: string }
> = {
  senior: {
    badge: "bg-blue-500/20 text-blue-300 border-blue-500/40",
    border: "border-blue-500/30",
    title: "Senior Sign In",
    subtitle: "ज्येष्ठ सदस्य उपस्थिती | Senior attendance only",
  },
  junior: {
    badge: "bg-purple-500/20 text-purple-300 border-purple-500/40",
    border: "border-purple-500/30",
    title: "Junior Sign In",
    subtitle: "कनिष्ठ सदस्य उपस्थिती | Junior attendance only",
  },
};

interface CategoryLoginFormProps {
  category: MemberCategory;
}

export function CategoryLoginForm({ category }: CategoryLoginFormProps) {
  const styles = categoryStyles[category];
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const oauthError = loginErrorMessage(searchParams.get("error"));
    if (oauthError) setError(oauthError);
  }, [searchParams]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const supabase = createClient();
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (signInError) {
        setError(signInError.message);
        setLoading(false);
        return;
      }

      if (!data.user) {
        setError("Sign-in failed. Please try again.");
        setLoading(false);
        return;
      }

      const { data: profile } = await supabase
        .from("profiles")
        .select("role, member_category")
        .eq("id", data.user.id)
        .single();

      const role = profile?.role ?? "user";
      const nextPath = getPostLoginPath(role, profile?.member_category, category);
      window.location.assign(nextPath);
      return;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Sign-in failed";
      setError(message);
      setLoading(false);
    }
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center p-6">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: "url(/branding/group-photo.jpg)" }}
      />
      <div className={`card relative w-full max-w-md border-2 ${styles.border}`}>
        <BrandingHeader subtitle="ढोल • ताशा • ध्वज पथक" />
        <span
          className={`mx-auto mt-4 flex w-fit rounded-full border px-4 py-1 text-xs font-semibold ${styles.badge}`}
        >
          {categoryLabel(category).toUpperCase()} ONLY
        </span>
        <h1 className="mt-4 text-center text-xl font-bold text-white">{styles.title}</h1>
        <p className="mt-1 text-center text-sm text-white/60">{styles.subtitle}</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="label">Email</label>
            <input
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@gmail.com"
            />
          </div>
          <div>
            <label className="label">Password</label>
            <input
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
            />
          </div>

          {error && (
            <p className="rounded-lg bg-red-500/20 px-4 py-2 text-sm text-red-300">{error}</p>
          )}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "..." : `${categoryLabel(category)} Sign In`}
          </button>
        </form>

        <Link
          href={`/user/${category}`}
          className="btn-secondary mt-4 block w-full py-2 text-center text-sm"
        >
          {categoryLabel(category)} Attendance
        </Link>
      </div>
    </main>
  );
}
