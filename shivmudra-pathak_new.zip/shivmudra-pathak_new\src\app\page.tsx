import { redirect } from "next/navigation";
import { getSessionProfile, roleDashboard } from "@/lib/auth";

export default async function Home() {
  const profile = await getSessionProfile();
  if (!profile) redirect("/login");
  redirect(roleDashboard(profile.role, profile.member_category));
}
