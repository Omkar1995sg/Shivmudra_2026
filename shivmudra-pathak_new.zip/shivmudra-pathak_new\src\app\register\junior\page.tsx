import { SelfRegisterForm } from "@/components/SelfRegisterForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Junior Registration | Shivmudra Pathak",
  description: "Junior pathak member registration only",
};

export default function JuniorRegisterPage() {
  return <SelfRegisterForm category="junior" />;
}