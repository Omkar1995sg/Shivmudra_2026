"use client";

import { AppNav } from "@/components/AppNav";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useState } from "react";

function RequestForm() {
  const params = useSearchParams();
  const router = useRouter();
  const userId = params.get("user") ?? "";
  const userName = params.get("name") ?? "";
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!userId || !reason) return;
    setLoading(true);

    const res = await fetch("/api/removal-requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId, reason }),
    });

    if (res.ok) {
      setMessage("Request sent to admin.");
      setTimeout(() => router.push("/leader"), 2000);
    } else {
      setMessage("Failed to send request.");
    }
    setLoading(false);
  }

  return (
    <form onSubmit={submit} className="card space-y-4">
      {userName && (
        <p className="text-white">
          Member: <strong>{decodeURIComponent(userName)}</strong>
        </p>
      )}
      {!userId && (
        <div>
          <label className="label">Member User ID</label>
          <input
            className="input"
            value={userId}
            onChange={() => {}}
            placeholder="Paste member ID from attendance page"
            required
          />
        </div>
      )}
      <div>
        <label className="label">Reason (irregular attendance)</label>
        <textarea
          className="input"
          rows={4}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          required
          placeholder="Member has not attended regularly..."
        />
      </div>
      <button type="submit" className="btn-primary w-full" disabled={loading}>
        {loading ? "Sending..." : "Raise Removal Request"}
      </button>
      {message && <p className="text-sm text-brand-500">{message}</p>}
    </form>
  );
}

export default function LeaderRequestsPage() {
  return (
    <>
      <AppNav role="leader" />
      <main className="mx-auto max-w-xl p-6">
        <h1 className="mb-6 text-2xl font-bold text-white">Removal Request</h1>
        <Suspense fallback={<p className="text-white/50">Loading...</p>}>
          <RequestForm />
        </Suspense>
      </main>
    </>
  );
}
