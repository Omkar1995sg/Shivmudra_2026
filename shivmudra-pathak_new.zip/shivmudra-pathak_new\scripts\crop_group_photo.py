"""Crop group photo — remove white/logo header; keep tagline + full crowd."""
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "public" / "branding" / "group-photo.jpg"
BACKUP = ROOT / "public" / "branding" / "group-photo-full.jpg"

# Keep tagline (y~370) with padding above; crowd starts ~y417
CROP_TOP = 352


def main() -> None:
    img = Image.open(SRC).convert("RGB")
    w, h = img.size

    if not BACKUP.exists():
        img.save(BACKUP, quality=92)
        print(f"Backup saved: {BACKUP}")

    cropped = img.crop((0, CROP_TOP, w, h))
    cropped.save(SRC, quality=92, optimize=True)
    print(f"Cropped {SRC}: {w}x{h} -> {cropped.size[0]}x{cropped.size[1]}")


if __name__ == "__main__":
    main()
