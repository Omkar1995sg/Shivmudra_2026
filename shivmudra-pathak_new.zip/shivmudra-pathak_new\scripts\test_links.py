"""Smoke-test all Shivmudra Pathak routes (server must be running on BASE)."""
import json
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:3000"

PAGES = [
    "/",
    "/login",
    "/register",
    "/admin",
    "/admin/registrations",
    "/admin/members",
    "/admin/members/new",
    "/admin/leaders",
    "/admin/geo-fence",
    "/admin/requests",
    "/admin/reports",
    "/leader",
    "/leader/requests",
    "/user",
]

APIS = [
    ("GET", "/api/registration/list", None),
    ("POST", "/api/registration", None),
    ("PATCH", "/api/registration/review", b"{}"),
    ("GET", "/api/members/list", None),
    ("GET", "/api/removal-requests/list", None),
    ("POST", "/api/removal-requests", b"{}"),
    ("PATCH", "/api/removal-requests", b"{}"),
    ("POST", "/api/leaders", b"{}"),
    ("POST", "/api/attendance/mark", b"{}"),
    ("GET", "/api/geo-fence", None),
    ("GET", "/api/reports/generate", None),
]


def fetch(method: str, path: str, body: bytes | None = None, follow_redirects: bool = True):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None

    handlers = [] if follow_redirects else [NoRedirect]
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(
        BASE + path,
        data=body,
        method=method,
        headers={"Content-Type": "application/json"} if body is not None else {},
    )
    try:
        with opener.open(req, timeout=45) as resp:
            return resp.status, dict(resp.headers), resp.read(500)
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read(500)
    except Exception as e:
        return 0, {}, str(e).encode()


def main():
    print("=== PAGES (unauthenticated, no redirect follow) ===")
    page_issues = []
    for path in PAGES:
        status, headers, _ = fetch("GET", path, follow_redirects=False)
        loc = headers.get("Location") or headers.get("location") or ""
        if path in ("/login", "/register"):
            ok = status == 200
        elif path == "/":
            ok = status in (307, 308, 302, 301)
        else:
            ok = status in (307, 308, 302, 301) and "login" in loc
        mark = "OK" if ok else "FAIL"
        print(f"{mark} {path} -> {status}" + (f" -> {loc}" if loc else ""))
        if not ok:
            page_issues.append(path)

    print("\n=== APIs (unauthenticated — expect 401 JSON) ===")
    api_issues = []
    for method, path, body in APIS:
        status, _, body_bytes = fetch(method, path, body, follow_redirects=False)
        snippet = body_bytes[:120].decode("utf-8", errors="replace")
        if path == "/api/registration" and method == "POST":
            acceptable = status in (400, 500)
        elif path == "/api/reports/generate" and method == "GET":
            acceptable = status in (401, 403)
        else:
            acceptable = status in (401, 403, 405) or (
                status == 400 and "error" in snippet
            )
        mark = "OK" if acceptable else "FAIL"
        print(f"{mark} {method} {path} -> {status} {snippet[:80]}")
        if not acceptable:
            api_issues.append(f"{method} {path}")

    print("\n=== SUMMARY ===")
    if not page_issues and not api_issues:
        print("All routes responded acceptably.")
    else:
        if page_issues:
            print("Page issues:", ", ".join(page_issues))
        if api_issues:
            print("API issues:", ", ".join(api_issues))


if __name__ == "__main__":
    main()
