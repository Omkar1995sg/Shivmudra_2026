import { AdminRegisterMemberForm } from "@/components/AdminRegisterMemberForm";

export default function RegisterSeniorMemberPage() {
  return <AdminRegisterMemberForm category="senior" />;
}
