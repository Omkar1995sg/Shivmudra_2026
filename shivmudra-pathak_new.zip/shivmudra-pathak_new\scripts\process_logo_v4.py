"""Shivmudra logo — transparent octagon + embossed white text."""
from __future__ import annotations

from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image, ImageEnhance

ROOT = Path(__file__).resolve().parents[1]
SRC_FULL = Path(r"C:\Users\omkarga\Downloads\Image (3).jpg")
SRC = ROOT / "public" / "branding" / "logo.jpg"
OUT_PNG = ROOT / "public" / "branding" / "logo.png"


def flood_white_from_edges(r: np.ndarray, g: np.ndarray, b: np.ndarray, thr: int = 232) -> np.ndarray:
    h, w = r.shape
    visited = np.zeros((h, w), dtype=bool)
    bg = np.zeros((h, w), dtype=bool)
    q: deque[tuple[int, int]] = deque()

    def is_white(y: int, x: int) -> bool:
        return r[y, x] > thr and g[y, x] > thr and b[y, x] > thr

    for x in range(w):
        for y in (0, h - 1):
            if is_white(y, x):
                q.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if is_white(y, x):
                q.append((y, x))

    while q:
        y, x = q.popleft()
        if y < 0 or y >= h or x < 0 or x >= w or visited[y, x]:
            continue
        if not is_white(y, x):
            continue
        visited[y, x] = True
        bg[y, x] = True
        q.extend([(y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)])
    return bg


def erode_white_halo(alpha: np.ndarray, r: np.ndarray, g: np.ndarray, b: np.ndarray, passes: int = 6) -> np.ndarray:
    h, w = alpha.shape
    a = alpha.copy()
    bright = (r > 215) & (g > 215) & (b > 215)
    for _ in range(passes):
        clear = np.zeros((h, w), dtype=bool)
        for y in range(h):
            for x in range(w):
                if a[y, x] < 128 or not bright[y, x]:
                    continue
                for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    ny, nx = y + dy, x + dx
                    if ny < 0 or ny >= h or nx < 0 or nx >= w or a[ny, nx] < 128:
                        clear[y, x] = True
                        break
        a[clear] = 0
    return a


def strip_edge_halo(r: np.ndarray, g: np.ndarray, b: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Remove anti-aliased white fringe touching transparent pixels."""
    h, w = alpha.shape
    a = alpha.copy()
    light = (r > 210) & (g > 210) & (b > 210)
    for y in range(h):
        for x in range(w):
            if a[y, x] < 128 or not light[y, x]:
                continue
            touches_clear = False
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and a[ny, nx] < 20:
                        touches_clear = True
                        break
                if touches_clear:
                    break
            if touches_clear:
                a[y, x] = 0
    return a


def emboss_white_letters(rgba: np.ndarray) -> np.ndarray:
    """Subtle raised effect on white Devanagari text."""
    out = rgba.astype(np.float32)
    r, g, b, a = out[:, :, 0], out[:, :, 1], out[:, :, 2], out[:, :, 3]
    white = (r > 200) & (g > 200) & (b > 200) & (a > 128)
    h, w = a.shape

    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if not white[y, x]:
                continue
            if not white[y - 1, x] or not white[y, x - 1]:
                out[y, x, 0:3] = np.minimum(255, out[y, x, 0:3] + 14)
            if not white[y + 1, x] or not white[y, x + 1]:
                out[y, x, 0:3] = np.maximum(180, out[y, x, 0:3] * 0.9)

    return np.clip(out, 0, 255).astype(np.uint8)


def main() -> None:
    src_path = SRC_FULL if SRC_FULL.exists() else SRC
    img = Image.open(src_path).convert("RGBA")
    w, h = img.size

    # Full octagon crop from master artwork (logo.jpg trims top/bottom points)
    if src_path == SRC_FULL:
        img = img.crop((int(w * 0.14), int(h * 0.02), int(w * 0.86), int(h * 0.88)))

    arr = np.array(img, dtype=np.float32)
    r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]

    bg = flood_white_from_edges(r, g, b, thr=230)
    alpha = np.where(bg, 0, 255).astype(np.uint8)
    alpha = erode_white_halo(alpha, r, g, b, passes=8)
    alpha = strip_edge_halo(r, g, b, alpha)

    rgba = np.dstack([r, g, b, alpha]).astype(np.uint8)
    result = Image.fromarray(rgba)
    bbox = result.getbbox()
    if bbox:
        result = result.crop(bbox)

    # Enhance seal texture (not global emboss filter)
    r, g, b, a = result.split()
    rgb = Image.merge("RGB", (r, g, b))
    rgb = ImageEnhance.Contrast(rgb).enhance(1.08)
    rgb = ImageEnhance.Sharpness(rgb).enhance(1.12)
    result = Image.merge("RGBA", (*rgb.split(), a))

    arr = np.array(result)
    arr = emboss_white_letters(arr)
    result = Image.fromarray(arr)

    rw, rh = result.size
    side = max(rw, rh)
    pad = max(8, int(side * 0.1))
    canvas = Image.new("RGBA", (side + pad * 2, side + pad * 2), (0, 0, 0, 0))
    canvas.paste(result, (pad + (side - rw) // 2, pad + (side - rh) // 2))
    result = canvas.resize((512, 512), Image.Resampling.LANCZOS)

    result.save(OUT_PNG, optimize=True)
    print(f"Saved {OUT_PNG} ({result.size}) from {src_path.name}")


if __name__ == "__main__":
    main()
