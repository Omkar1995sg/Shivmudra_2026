"use client";

import { AppNav } from "@/components/AppNav";
import { BLOOD_GROUPS, categoryLabel, type MemberCategory } from "@/lib/member-fields";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

interface AdminRegisterMemberFormProps {
  category: MemberCategory;
}

export function AdminRegisterMemberForm({ category }: AdminRegisterMemberFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [previousPathak, setPreviousPathak] = useState(false);
  const label = categoryLabel(category);
  const borderAccent = category === "senior" ? "border-blue-500/40" : "border-purple-500/40";
  const badge =
    category === "senior"
      ? "bg-blue-500/20 text-blue-300 border-blue-500/40"
      : "bg-purple-500/20 text-purple-300 border-purple-500/40";
  const titleColor = category === "senior" ? "text-blue-400" : "text-purple-400";

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const form = e.currentTarget;
    const formData = new FormData(form);
    formData.set("previous_pathak", String(previousPathak));
    formData.set("member_category", category);

    try {
      const res = await fetch("/api/members", { method: "POST", body: formData });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setError(data.error ?? "Failed");
        return;
      }

      router.push(`/admin/${category}`);
      router.refresh();
    } catch {
      setError("Network error — could not reach the server");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-2xl p-6">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <Link href="/admin" className="text-sm text-white/50 hover:text-white">
            ← Dashboard
          </Link>
          <Link href={`/admin/${category}`} className="text-sm text-white/50 hover:text-white">
            {label} Dashboard
          </Link>
        </div>

        <span className={`mb-3 inline-block rounded-full border px-3 py-1 text-xs font-semibold ${badge}`}>
          {label.toUpperCase()} ONLY
        </span>
        <h1 className={`mb-6 text-2xl font-bold ${titleColor}`}>Register {label} Member</h1>

        <form onSubmit={handleSubmit} className={`card space-y-4 border ${borderAccent}`}>
          <input type="hidden" name="member_category" value={category} />

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Name *</label>
              <input name="name" className="input" required />
            </div>
            <div>
              <label className="label">Contact Number *</label>
              <input name="phone" type="tel" className="input" required pattern="[0-9]{10}" />
            </div>
          </div>

          <div>
            <label className="label">Address</label>
            <textarea name="address" className="input" rows={2} />
          </div>

          <div>
            <label className="label">Blood Group *</label>
            <select name="blood_group" className="input" required>
              <option value="">Select</option>
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Instrument *</label>
              <select name="instrument" className="input" required>
                <option value="dhol">Dhol-Dhwaj</option>
                <option value="tasha">Tasha-Dhwaj</option>
                <option value="dhawaj">Dhwaj</option>
              </select>
            </div>
            <div>
              <label className="label">Reference</label>
              <input name="reference" className="input" placeholder="Who referred?" />
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm text-white/80">
              <input
                type="checkbox"
                checked={previousPathak}
                onChange={(e) => setPreviousPathak(e.target.checked)}
              />
              Was part of any pathak before?
            </label>
            {previousPathak && (
              <input
                name="previous_pathak_name"
                className="input mt-2"
                placeholder="Previous pathak name"
              />
            )}
          </div>

          <div>
            <label className="label">Passport Size Photo</label>
            <input name="photo" type="file" accept="image/*" className="input" />
          </div>

          <hr className="border-white/10" />
          <p className="text-sm text-white/50">Login credentials for this {label.toLowerCase()} member</p>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Email *</label>
              <input name="email" type="email" className="input" required />
            </div>
            <div>
              <label className="label">Password *</label>
              <input name="password" type="password" className="input" required minLength={6} />
            </div>
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "Registering..." : `Register ${label} Member`}
          </button>
        </form>
      </main>
    </>
  );
}
