"use client";

import { createClient } from "@/lib/supabase/client";
import { useSearchParams } from "next/navigation";
import { useState, useEffect, Suspense } from "react";
import { BrandingHeader } from "@/components/BrandingHeader";
import { getPostLoginPath, loginErrorMessage } from "@/lib/auth-redirect";

function AdminLoginForm() {
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const oauthError = loginErrorMessage(searchParams.get("error"));
    if (oauthError) setError(oauthError);
  }, [searchParams]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const supabase = createClient();
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (signInError) {
        setError(signInError.message);
        setLoading(false);
        return;
      }

      if (!data.user) {
        setError("Sign-in failed. Please try again.");
        setLoading(false);
        return;
      }

      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("role, member_category")
        .eq("id", data.user.id)
        .single();

      if (profileError) {
        console.error("profile lookup failed", profileError);
      }

      const role = profile?.role ?? "user";
      const nextPath = getPostLoginPath(role, profile?.member_category, "admin");
      // Full navigation so auth cookies are applied before middleware/page load.
      window.location.assign(nextPath);
      return;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Sign-in failed";
      setError(message);
      setLoading(false);
    }
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center p-6">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: "url(/branding/group-photo.jpg)" }}
      />
      <div className="card relative w-full max-w-md">
        <BrandingHeader subtitle="ढोल • ताशा • ध्वज पथक" />
        <p className="mt-4 text-center text-sm text-white/50">Admin / staff sign in</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="label">Email</label>
            <input
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@gmail.com"
            />
          </div>
          <div>
            <label className="label">Password</label>
            <input
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
            />
          </div>

          {error && (
            <p className="rounded-lg bg-red-500/20 px-4 py-2 text-sm text-red-300">{error}</p>
          )}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "..." : "Sign In"}
          </button>
        </form>

        <div className="mt-6 grid gap-2 text-center text-sm">
          <a href="/login/senior" className="text-blue-400 hover:underline">
            Senior Sign In & Attendance
          </a>
          <a href="/login/junior" className="text-purple-400 hover:underline">
            Junior Sign In & Attendance
          </a>
        </div>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="p-6 text-center text-white/50">Loading...</div>}>
      <AdminLoginForm />
    </Suspense>
  );
}
