import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profileError || !profile) {
    return NextResponse.json({ error: "Profile not found" }, { status: 403 });
  }

  if (profile.role !== "admin") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const { data: requests } = await supabase
    .from("removal_requests")
    .select("id, reason, status, created_at, user_id, raised_by")
    .order("created_at", { ascending: false });

  if (!requests?.length) return NextResponse.json([]);

  const userIds = [...new Set(requests.flatMap((r) => [r.user_id, r.raised_by]))];
  const { data: profiles } = await supabase
    .from("profiles")
    .select("id, name, phone, instrument")
    .in("id", userIds);

  const profileMap = new Map(profiles?.map((p) => [p.id, p]) ?? []);

  const result = requests.map((r) => ({
    ...r,
    user: profileMap.get(r.user_id) ?? { name: "Unknown", phone: "", instrument: "" },
    leader: { name: profileMap.get(r.raised_by)?.name ?? "Unknown" },
  }));

  return NextResponse.json(result);
}
