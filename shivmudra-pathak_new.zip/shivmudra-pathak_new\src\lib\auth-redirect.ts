import type { MemberCategory } from "@/lib/member-fields";

export type LoginContext = "admin" | MemberCategory;
export type AuthFlow = "login" | "register";

export function isGmailEmail(email: string): boolean {
  const normalized = email.trim().toLowerCase();
  return normalized.endsWith("@gmail.com") || normalized.endsWith("@googlemail.com");
}

export function isMemberCategory(value: string | null): value is MemberCategory {
  return value === "senior" || value === "junior";
}

export function getRegisterPathForCategory(category: MemberCategory): string {
  return `/register/${category}`;
}

export function getPostLoginPath(
  role: string,
  memberCategory: string | null | undefined,
  context: LoginContext
): string {
  if (role === "admin") {
    return context === "admin" ? "/admin" : `/admin/${context}`;
  }
  if (role === "leader") return "/leader";
  if (context === "admin") {
    if (memberCategory === "senior" || memberCategory === "junior") {
      return `/user/${memberCategory}`;
    }
    return "/user";
  }
  return `/user/${context}`;
}

export function getLoginPathForContext(context: LoginContext): string {
  return context === "admin" ? "/login" : `/login/${context}`;
}

export function loginErrorMessage(code: string | null): string | null {
  if (code === "gmail_only") {
    return "Please sign in with a Gmail account (@gmail.com).";
  }
  if (code === "auth") {
    return "Google sign-in failed. Try again or use email and password.";
  }
  return null;
}

export function registerErrorMessage(code: string | null): string | null {
  if (code === "gmail_only") {
    return "Please register with a Gmail account (@gmail.com).";
  }
  if (code === "auth") {
    return "Google sign-in failed. Try again.";
  }
  if (code === "already_submitted") {
    return "Registration already submitted. Wait for admin approval or sign in.";
  }
  if (code === "already_registered") {
    return "You are already registered. Please sign in.";
  }
  return null;
}
