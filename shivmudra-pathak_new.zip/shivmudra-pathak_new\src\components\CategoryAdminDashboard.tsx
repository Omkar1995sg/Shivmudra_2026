import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { AppNav } from "@/components/AppNav";
import { getISTDateString } from "@/lib/attendance-window";
import { fetchInstrumentDashboardData } from "@/lib/attendance-stats-server";
import { categoryLabel, type MemberCategory } from "@/lib/member-fields";
import { InstrumentAttendanceDashboard } from "@/components/InstrumentAttendanceDashboard";
import Link from "next/link";

interface CategoryDashboardProps {
  category: MemberCategory;
}

export async function CategoryAdminDashboard({ category }: CategoryDashboardProps) {
  const profile = await requireRole(["admin"]);
  const supabase = await createClient();
  const today = getISTDateString();
  const label = categoryLabel(category);
  const borderAccent =
    category === "senior" ? "border-l-blue-500" : "border-l-purple-500";
  const textAccent = category === "senior" ? "text-blue-400" : "text-purple-400";

  const [{ todayStats, dailyHistory, memberList, presentIds }, { count: pendingInCategory }] =
    await Promise.all([
      fetchInstrumentDashboardData(supabase, today),
      supabase
        .from("profiles")
        .select("*", { count: "exact", head: true })
        .eq("role", "user")
        .eq("approval_status", "pending")
        .eq("member_category", category),
    ]);

  const categoryMembers = memberList.filter((m) => m.member_category === category);
  const total = categoryMembers.length;
  const present = categoryMembers.filter((m) => presentIds.has(m.id)).length;
  const absent = total - present;

  return (
    <>
      <AppNav role="admin" />
      <main className="mx-auto max-w-6xl p-6">
        <div className="mb-2 flex flex-wrap items-center gap-3">
          <Link href="/admin" className="text-sm text-white/50 hover:text-white">
            ← All Dashboard
          </Link>
        </div>
        <h1 className="mb-2 text-2xl font-bold text-white">{label} Dashboard</h1>
        <p className="mb-8 text-white/60">Welcome, {profile.name || profile.email}</p>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className={`card border-l-4 ${borderAccent}`}>
            <p className="text-sm text-white/50">{label} Members</p>
            <p className={`text-3xl font-bold ${textAccent}`}>{total}</p>
          </div>
          <div className="card">
            <p className="text-sm text-white/50">{label} Present Today</p>
            <p className="text-3xl font-bold text-green-400">{present}</p>
          </div>
          <div className="card">
            <p className="text-sm text-white/50">{label} Absent Today</p>
            <p className="text-3xl font-bold text-red-400">{absent}</p>
          </div>
          <div className="card">
            <p className="text-sm text-white/50">Pending {label} Registrations</p>
            <p className="text-3xl font-bold text-orange-400">{pendingInCategory ?? 0}</p>
          </div>
        </div>

        <div className="mt-10">
          <InstrumentAttendanceDashboard
            today={today}
            todayStats={todayStats}
            dailyHistory={dailyHistory}
          />
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <Link href={`/admin/members/new/${category}`} className="btn-primary text-sm">
            + Add {label} Member
          </Link>
          <Link href={`/register/${category}`} className="btn-secondary text-sm">
            {label} Registration Link
          </Link>
          <Link href={`/user/${category}`} className="btn-secondary text-sm">
            {label} Attendance Link
          </Link>
          <Link href="/admin/registrations" className="btn-secondary text-sm">
            Review Registrations
          </Link>
          <Link href="/admin/reports" className="btn-secondary text-sm">
            Download Report
          </Link>
        </div>
      </main>
    </>
  );
}
