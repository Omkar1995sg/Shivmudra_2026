import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { generateDailyReport } from "@/lib/excel-report";
import { getISTDateString } from "@/lib/attendance-window";

export async function GET(request: Request) {
  const authHeader = request.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;

  const supabase = createAdminClient();
  const url = new URL(request.url);
  const isCron = authHeader === `Bearer ${cronSecret}`;

  if (!isCron) {
    const { createClient } = await import("@/lib/supabase/server");
    const userClient = await createClient();
    const {
      data: { user },
    } = await userClient.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { data: profile } = await userClient
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (profile?.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
  }

  const today = url.searchParams.get("date") ?? getISTDateString();

  const { data: members } = await supabase
    .from("profiles")
    .select("*")
    .eq("role", "user")
    .eq("approval_status", "approved");
  const { data: todayAttendance } = await supabase
    .from("attendance")
    .select("*")
    .eq("attendance_date", today);

  const thirtyDaysAgo = new Date(today);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const { data: recentAttendance } = await supabase
    .from("attendance")
    .select("*")
    .gte("attendance_date", thirtyDaysAgo.toISOString().slice(0, 10));

  const buffer = await generateDailyReport(
    members ?? [],
    todayAttendance ?? [],
    recentAttendance ?? [],
    today
  );

  await supabase.from("daily_reports").upsert(
    { report_date: today, generated_at: new Date().toISOString() },
    { onConflict: "report_date" }
  );

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="shivmudra-attendance-${today}.xlsx"`,
    },
  });
}
