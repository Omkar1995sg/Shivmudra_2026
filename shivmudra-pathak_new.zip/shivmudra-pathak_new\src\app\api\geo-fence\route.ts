import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = await createClient();
  const { data } = await supabase.from("practice_ground").select("*").limit(1).single();
  return NextResponse.json(data);
}

export async function PUT(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profile?.role !== "admin") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const { center_lat, center_lng, radius_meters, name } = await request.json();

  const { data: existing } = await supabase.from("practice_ground").select("id").limit(1).single();

  if (existing) {
    const { error } = await supabase
      .from("practice_ground")
      .update({
        center_lat,
        center_lng,
        radius_meters,
        name: name ?? "Shivmudra Sarav Ground",
        set_by: user.id,
        updated_at: new Date().toISOString(),
      })
      .eq("id", existing.id);

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  } else {
    const { error } = await supabase.from("practice_ground").insert({
      center_lat,
      center_lng,
      radius_meters,
      name: name ?? "Shivmudra Sarav Ground",
      set_by: user.id,
    });

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
