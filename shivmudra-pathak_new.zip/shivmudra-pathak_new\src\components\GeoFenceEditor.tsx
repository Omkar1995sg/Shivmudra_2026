"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";

const MapPicker = dynamic(() => import("./MapPicker"), { ssr: false });

interface GeoFenceEditorProps {
  initialLat: number;
  initialLng: number;
  initialRadius: number;
  onSave: (lat: number, lng: number, radius: number) => Promise<void>;
}

export function GeoFenceEditor({
  initialLat,
  initialLng,
  initialRadius,
  onSave,
}: GeoFenceEditorProps) {
  const [lat, setLat] = useState(initialLat);
  const [lng, setLng] = useState(initialLng);
  const [radius, setRadius] = useState(initialRadius);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    setLat(initialLat);
    setLng(initialLng);
    setRadius(initialRadius);
  }, [initialLat, initialLng, initialRadius]);

  async function handleSave() {
    setSaving(true);
    setMessage("");
    try {
      await onSave(lat, lng, radius);
      setMessage("Geo-fence saved successfully!");
    } catch {
      setMessage("Failed to save. Try again.");
    }
    setSaving(false);
  }

  return (
    <div className="space-y-6">
      <MapPicker lat={lat} lng={lng} radius={radius} onChange={(la, ln) => { setLat(la); setLng(ln); }} />

      <div className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="label">Latitude</label>
          <input type="number" step="any" className="input" value={lat} onChange={(e) => setLat(parseFloat(e.target.value))} />
        </div>
        <div>
          <label className="label">Longitude</label>
          <input type="number" step="any" className="input" value={lng} onChange={(e) => setLng(parseFloat(e.target.value))} />
        </div>
        <div>
          <label className="label">Radius (meters)</label>
          <input type="number" min={50} max={300} className="input" value={radius} onChange={(e) => setRadius(parseInt(e.target.value, 10))} />
        </div>
      </div>

      <p className="text-sm text-white/60">
        Users can mark attendance only within <strong>{radius}m</strong> of this point (8:30–9:30 PM).
      </p>

      <button onClick={handleSave} className="btn-primary" disabled={saving}>
        {saving ? "Saving..." : "Save Geo-Fence"}
      </button>

      {message && <p className="text-sm text-brand-500">{message}</p>}
    </div>
  );
}
