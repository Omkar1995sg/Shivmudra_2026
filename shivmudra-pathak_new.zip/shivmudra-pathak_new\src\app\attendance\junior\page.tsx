import { AttendanceEntryPage } from "@/components/AttendanceEntryPage";

export default function JuniorAttendanceEntryPage() {
  return <AttendanceEntryPage category="junior" />;
}
