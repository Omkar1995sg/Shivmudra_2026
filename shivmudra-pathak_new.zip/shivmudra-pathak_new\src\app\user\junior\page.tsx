import { AttendancePanel } from "@/components/AttendancePanel";

export default function JuniorAttendancePage() {
  return <AttendancePanel portalCategory="junior" />;
}
