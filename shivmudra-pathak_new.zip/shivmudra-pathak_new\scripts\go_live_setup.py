"""One-time go-live checks: geo-fence seed + approve pending registrations."""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = ROOT / ".env.local"

# Default Pune center — admin should confirm on Admin → Geo Fence map
DEFAULT_GEO = {
    "center_lat": 18.5204,
    "center_lng": 73.8567,
    "radius_meters": 150,
    "name": "Shivmudra Sarav Ground",
}


def load_env(path: Path) -> dict[str, str]:
    env: dict[str, str] = {}
    if not path.exists():
        return env
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip()
    return env


def sb_request(
    base: str,
    key: str,
    method: str,
    path: str,
    body: dict | list | None = None,
    prefer: str | None = None,
) -> tuple[int, object]:
    url = f"{base.rstrip('/')}/rest/v1/{path}"
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
    headers = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    if prefer:
        headers["Prefer"] = prefer
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, json.loads(raw) if raw else []
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8")
        try:
            payload = json.loads(raw) if raw else {"error": e.reason}
        except json.JSONDecodeError:
            payload = {"error": raw or e.reason}
        return e.code, payload


def main() -> int:
    env = load_env(ENV_FILE)
    base = env.get("NEXT_PUBLIC_SUPABASE_URL", "")
    service_key = env.get("SUPABASE_SERVICE_ROLE_KEY", "")

    if not base or not service_key:
        print("ERROR: Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env.local")
        return 1

    print("=== Shivmudra Pathak — Go-Live Setup ===\n")

    # 1. Geo-fence
    status, ground = sb_request(base, service_key, "GET", "practice_ground?select=*&limit=1")
    if status != 200:
        print(f"ERROR reading practice_ground: {ground}")
        return 1

    if ground and isinstance(ground, list) and len(ground) > 0:
        g = ground[0]
        print("Geo-fence: ALREADY SET")
        print(f"  Name:   {g.get('name')}")
        print(f"  Lat/Lng: {g.get('center_lat')}, {g.get('center_lng')}")
        print(f"  Radius: {g.get('radius_meters')}m")
    else:
        status, created = sb_request(
            base,
            service_key,
            "POST",
            "practice_ground",
            DEFAULT_GEO,
            prefer="return=representation",
        )
        if status not in (200, 201):
            print(f"ERROR seeding geo-fence: {created}")
            return 1
        g = created[0] if isinstance(created, list) else created
        print("Geo-fence: SEEDED (default Pune coordinates)")
        print(f"  Lat/Lng: {g.get('center_lat')}, {g.get('center_lng')}")
        print(f"  Radius: {g.get('radius_meters')}m")
        print("  >> Confirm/adjust at Admin → Geo Fence on the map before go-live")

    print()

    # 2. Pending registrations
    status, pending = sb_request(
        base,
        service_key,
        "GET",
        "profiles?select=id,name,email,member_category,approval_status&role=eq.user&approval_status=eq.pending",
    )
    if status != 200:
        print(f"ERROR reading pending registrations: {pending}")
        return 1

    pending = pending if isinstance(pending, list) else []
    if not pending:
        print("Registrations: No pending members to approve")
    else:
        print(f"Registrations: Approving {len(pending)} pending member(s)...")
        approved = 0
        for member in pending:
            mid = member["id"]
            name = member.get("name", "")
            patch_status, patch_result = sb_request(
                base,
                service_key,
                "PATCH",
                f"profiles?id=eq.{mid}",
                {"approval_status": "approved", "status": "active"},
                prefer="return=minimal",
            )
            if patch_status in (200, 204):
                approved += 1
                print(f"  APPROVED: {name} ({member.get('email', '')})")
            else:
                print(f"  FAILED: {name} — {patch_result}")

        print(f"Registrations: {approved}/{len(pending)} approved")

    print()
    print("=== Done ===")
    print("- Attendance time window: 8:30–9:30 PM IST (re-enabled in API)")
    print("- Next: run `npm run dev` and verify Admin -> Geo Fence on map")
    return 0


if __name__ == "__main__":
    sys.exit(main())
