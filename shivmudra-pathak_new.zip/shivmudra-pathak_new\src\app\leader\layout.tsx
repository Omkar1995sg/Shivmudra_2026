import { requireRole } from "@/lib/auth";

export default async function LeaderLayout({ children }: { children: React.ReactNode }) {
  await requireRole(["leader", "admin"]);
  return <>{children}</>;
}
