import type { SupabaseClient } from "@supabase/supabase-js";

const MIME_BY_EXT: Record<string, string> = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  gif: "image/gif",
};

export function memberPhotosBucket(): string {
  return (
    process.env.SUPABASE_PHOTOS_BUCKET?.trim() || "Shivmudra_attendance_bucket_2026"
  );
}

export function photoContentType(file: File, ext: string): string {
  if (file.type && file.type.startsWith("image/")) return file.type;
  return MIME_BY_EXT[ext.toLowerCase()] ?? "image/jpeg";
}

export async function uploadMemberPhoto(
  adminClient: SupabaseClient,
  userId: string,
  photo: File | null
): Promise<{ photo_url: string | null; error: string | null }> {
  if (!photo || photo.size === 0) {
    return { photo_url: null, error: null };
  }

  const bucket = memberPhotosBucket();
  const ext = (photo.name.split(".").pop() ?? "jpg").toLowerCase();
  const path = `${userId}/photo.${ext}`;
  const buffer = Buffer.from(await photo.arrayBuffer());
  const contentType = photoContentType(photo, ext);

  const { error: uploadError } = await adminClient.storage
    .from(bucket)
    .upload(path, buffer, { contentType, upsert: true });

  if (uploadError) {
    const hint =
      uploadError.message?.toLowerCase().includes("not found") ||
      uploadError.message?.toLowerCase().includes("bucket")
        ? ` Set SUPABASE_PHOTOS_BUCKET in .env.local to your Supabase bucket name (yours: Shivmudra_attendance_bucket_2026).`
        : "";
    return {
      photo_url: null,
      error: `${uploadError.message}${hint}`,
    };
  }

  const { data: urlData } = adminClient.storage.from(bucket).getPublicUrl(path);
  return { photo_url: urlData.publicUrl, error: null };
}
