import { AttendanceEntryPage } from "@/components/AttendanceEntryPage";

export default function SeniorAttendanceEntryPage() {
  return <AttendanceEntryPage category="senior" />;
}
