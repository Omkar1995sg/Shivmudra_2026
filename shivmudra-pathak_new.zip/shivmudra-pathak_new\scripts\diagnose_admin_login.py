"""Diagnose admin login without printing secrets."""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV = ROOT / ".env.local"
EMAIL = "omkargavkhadkar@gmail.com"


def load_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def req(url: str, headers: dict[str, str], method: str = "GET", body: dict | None = None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    headers = dict(headers)
    if body is not None:
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else None
        except json.JSONDecodeError:
            payload = {"raw": raw[:500]}
        return e.code, payload
    except Exception as e:  # noqa: BLE001
        return 0, {"error": str(e)}


def main() -> int:
    if not ENV.exists():
        print("FAIL: .env.local missing")
        return 1
    env = load_env(ENV)
    url = env.get("NEXT_PUBLIC_SUPABASE_URL", "").rstrip("/")
    anon = env.get("NEXT_PUBLIC_SUPABASE_ANON_KEY", "")
    service = env.get("SUPABASE_SERVICE_ROLE_KEY", "")
    bootstrap = (env.get("BOOTSTRAP_ADMIN_EMAIL") or "").strip().lower()

    print("=== config presence ===")
    print(f"SUPABASE_URL set: {bool(url)}")
    print(f"ANON_KEY set: {bool(anon)}")
    print(f"SERVICE_ROLE set: {bool(service)}")
    print(f"BOOTSTRAP matches target: {bootstrap == EMAIL}")
    print(f"URL host: {url.split('//')[-1].split('/')[0] if url else 'NONE'}")

    if not url or not service:
        print("FAIL: missing supabase admin credentials")
        return 1

    headers = {
        "apikey": service,
        "Authorization": f"Bearer {service}",
    }

    # List auth users (admin API)
    status, users_payload = req(
        f"{url}/auth/v1/admin/users?page=1&per_page=200",
        headers,
    )
    print(f"=== auth admin users status={status} ===")
    if status != 200 or not isinstance(users_payload, dict):
        print("FAIL list users:", users_payload)
        return 1

    users = users_payload.get("users") or []
    print(f"total_users_page1: {len(users)}")
    match = None
    for u in users:
        if (u.get("email") or "").lower() == EMAIL:
            match = u
            break

    if not match:
        print(f"RESULT: auth user NOT FOUND for {EMAIL}")
        print("Likely cause: account was never created / wrong project")
        # Also check profiles table for any admin rows
        st, profiles = req(
            f"{url}/rest/v1/profiles?select=id,email,role,status,registration_status&role=eq.admin",
            {**headers, "Prefer": "count=exact"},
        )
        print(f"admin profiles query status={st}")
        if isinstance(profiles, list):
            print(f"admin_profile_count: {len(profiles)}")
            for p in profiles[:10]:
                print(
                    "admin_profile:",
                    {
                        "email": p.get("email"),
                        "role": p.get("role"),
                        "status": p.get("status"),
                        "registration_status": p.get("registration_status"),
                    },
                )
        return 2

    print("RESULT: auth user FOUND")
    print(
        "auth_user:",
        {
            "id": match.get("id"),
            "email": match.get("email"),
            "email_confirmed_at": match.get("email_confirmed_at"),
            "banned_until": match.get("banned_until"),
            "created_at": match.get("created_at"),
            "last_sign_in_at": match.get("last_sign_in_at"),
            "providers": (match.get("app_metadata") or {}).get("providers"),
            "identities": [
                {
                    "provider": i.get("provider"),
                    "email": (i.get("identity_data") or {}).get("email"),
                }
                for i in (match.get("identities") or [])
            ],
        },
    )

    uid = match["id"]
    st, profile = req(
        f"{url}/rest/v1/profiles?select=*&id=eq.{uid}",
        headers,
    )
    print(f"=== profile status={st} ===")
    if isinstance(profile, list) and profile:
        p = profile[0]
        print(
            "profile:",
            {
                "email": p.get("email"),
                "role": p.get("role"),
                "status": p.get("status"),
                "registration_status": p.get("registration_status"),
                "member_category": p.get("member_category"),
                "full_name": p.get("full_name"),
            },
        )
    else:
        print("RESULT: profile MISSING for auth user")
        print("profile_payload:", profile)

    # Probe password login with wrong password to distinguish invalid credentials vs other errors
    if anon:
        st, auth_err = req(
            f"{url}/auth/v1/token?grant_type=password",
            {"apikey": anon, "Authorization": f"Bearer {anon}"},
            method="POST",
            body={"email": EMAIL, "password": "__definitely_wrong_password__"},
        )
        print(f"=== wrong-password probe status={st} ===")
        if isinstance(auth_err, dict):
            print(
                "wrong_password_error:",
                {
                    "error": auth_err.get("error"),
                    "error_description": auth_err.get("error_description"),
                    "msg": auth_err.get("msg"),
                    "code": auth_err.get("code"),
                },
            )

    return 0


if __name__ == "__main__":
    sys.exit(main())
