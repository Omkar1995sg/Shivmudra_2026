"use client";

import Link from "next/link";
import { useState } from "react";
import { BLOOD_GROUPS, type MemberCategory, categoryLabel } from "@/lib/member-fields";
import { BrandingHeader } from "@/components/BrandingHeader";
import { GroupPhotoBackground } from "@/components/GroupPhotoBackground";

interface SelfRegisterFormProps {
  category: MemberCategory;
}

const categoryStyles: Record<
  MemberCategory,
  { badge: string; border: string; title: string; subtitle: string }
> = {
  senior: {
    badge: "bg-blue-500/20 text-blue-300 border-blue-500/40",
    border: "border-blue-500/30",
    title: "Senior Pathak Registration",
    subtitle: "केवळ ज्येष्ठ सदस्य नोंदणी | Senior members only",
  },
  junior: {
    badge: "bg-purple-500/20 text-purple-300 border-purple-500/40",
    border: "border-purple-500/30",
    title: "Junior Pathak Registration",
    subtitle: "केवळ कनिष्ठ सदस्य नोंदणी | Junior members only",
  },
};

export function SelfRegisterForm({ category }: SelfRegisterFormProps) {
  const styles = categoryStyles[category];
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [photoNote, setPhotoNote] = useState("");
  const [success, setSuccess] = useState(false);
  const [previousPathak, setPreviousPathak] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError("");
    setPhotoNote("");

    const form = e.currentTarget;
    const formData = new FormData(form);
    formData.set("previous_pathak", String(previousPathak));
    formData.set("member_category", category);

    try {
      const res = await fetch("/api/registration", { method: "POST", body: formData });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setError(data.error ?? "Registration failed");
        return;
      }

      setSuccess(true);
      if (data.photoNote) setPhotoNote(data.photoNote);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error — could not reach the server");
    } finally {
      setLoading(false);
    }
  }

  if (success) {
    return (
      <main className="relative flex min-h-screen flex-col items-center justify-center p-6">
        <GroupPhotoBackground />
        <div className={`card relative w-full max-w-md border-2 text-center ${styles.border}`}>
          <BrandingHeader compact />
          <span
            className={`mt-4 inline-block rounded-full border px-3 py-1 text-xs font-medium ${styles.badge}`}
          >
            {categoryLabel(category)} Registration Complete
          </span>
          <h1 className="mt-4 text-xl font-bold text-white">Registration Submitted</h1>
          <p className="mt-4 text-sm text-white/70">
            Your {categoryLabel(category).toLowerCase()} registration has been sent for admin review.
            You may sign in after approval to mark attendance.
          </p>
          {photoNote && (
            <p className="mt-4 rounded-lg border border-yellow-500/40 bg-yellow-500/10 p-3 text-sm text-yellow-300">
              {photoNote}
            </p>
          )}
          <Link href={`/login/${category}`} className="btn-primary mt-8 inline-block w-full">
            Go to {categoryLabel(category)} Sign In
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="relative min-h-screen">
      <GroupPhotoBackground />
      <div className="relative mx-auto max-w-2xl p-6">
        <div className="mb-6">
          <BrandingHeader />
          <span
            className={`mx-auto mt-4 flex w-fit rounded-full border px-4 py-1 text-xs font-semibold tracking-wide ${styles.badge}`}
          >
            {categoryLabel(category).toUpperCase()} ONLY
          </span>
          <h1 className="mt-4 text-center text-2xl font-bold text-white">{styles.title}</h1>
          <p className="mt-2 text-center text-sm text-white/60">{styles.subtitle}</p>
        </div>

        <form onSubmit={handleSubmit} className={`card space-y-4 border-2 ${styles.border}`}>
          <input type="hidden" name="member_category" value={category} readOnly />

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Full Name *</label>
              <input name="name" className="input" required />
            </div>
            <div>
              <label className="label">Contact Number *</label>
              <input name="phone" type="tel" className="input" required pattern="[0-9]{10}" />
            </div>
          </div>

          <div>
            <label className="label">Email (Gmail ID) *</label>
            <input name="email" type="email" className="input" required placeholder="you@gmail.com" />
          </div>

          <div>
            <label className="label">Address</label>
            <textarea name="address" className="input" rows={2} />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">Blood Group *</label>
              <select name="blood_group" className="input" required>
                <option value="">Select</option>
                {BLOOD_GROUPS.map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Instrument *</label>
              <select name="instrument" className="input" required>
                <option value="dhol">Dhol-Dhwaj</option>
                <option value="tasha">Tasha-Dhwaj</option>
                <option value="dhawaj">Dhwaj</option>
              </select>
            </div>
          </div>

          <div>
            <label className="label">Reference (optional)</label>
            <input name="reference" className="input" placeholder="Who referred you?" />
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm text-white/80">
              <input
                type="checkbox"
                checked={previousPathak}
                onChange={(e) => setPreviousPathak(e.target.checked)}
              />
              Was part of any pathak before?
            </label>
            {previousPathak && (
              <input
                name="previous_pathak_name"
                className="input mt-2"
                placeholder="Previous pathak name"
              />
            )}
          </div>

          <div>
            <label className="label">Passport-Size Photograph</label>
            <input name="photo" type="file" accept="image/*" className="input" />
          </div>

          <hr className="border-white/10" />
          <p className="text-sm text-white/50">Create your login password</p>

          <div>
            <label className="label">Password *</label>
            <input name="password" type="password" className="input" required minLength={6} />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "Submitting..." : `Submit ${categoryLabel(category)} Registration`}
          </button>

          <p className="text-center text-sm text-white/50">
            Already registered?{" "}
            <Link href={`/login/${category}`} className="text-brand-500 hover:underline">
              {categoryLabel(category)} Sign In
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
}
