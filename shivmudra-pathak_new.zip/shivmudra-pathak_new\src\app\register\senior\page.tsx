import { SelfRegisterForm } from "@/components/SelfRegisterForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Senior Registration | Shivmudra Pathak",
  description: "Senior pathak member registration only",
};

export default function SeniorRegisterPage() {
  return <SelfRegisterForm category="senior" />;
}
