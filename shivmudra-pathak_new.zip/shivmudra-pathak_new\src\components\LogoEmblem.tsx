interface LogoEmblemProps {
  compact?: boolean;
}

export function LogoEmblem({ compact = false }: LogoEmblemProps) {
  const width = compact ? 140 : 184;
  const height = compact ? 156 : 204;

  return (
    <div
      className="logo-emblem-wrap mx-auto flex items-center justify-center overflow-visible"
      style={{ width, height, minWidth: width, minHeight: height }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/branding/logo.png?v=5"
        alt="शिवमुद्रा"
        width={width}
        height={height}
        className="logo-emblem h-full w-full object-contain"
        draggable={false}
      />
    </div>
  );
}
